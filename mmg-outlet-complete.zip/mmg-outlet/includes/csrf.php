<?php
/**
 * M.M.G OUTLET - CSRF Protection
 * Simple CSRF token generation and validation
 */

if (!defined('MMG_ACCESS')) {
    define('MMG_ACCESS', true);
}

startSecureSession();

/**
 * Generate a new CSRF token
 */
function csrf_generate() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $_SESSION['csrf_token_time'] = time();
    }
    return $_SESSION['csrf_token'];
}

/**
 * Get current CSRF token
 */
function csrf_token() {
    return csrf_generate();
}

/**
 * Validate CSRF token from POST request
 */
function csrf_validate() {
    $token = $_POST['csrf_token'] ?? '';
    return validateCsrfToken($token);
}

/**
 * Regenerate CSRF token
 */
function csrf_refresh() {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    $_SESSION['csrf_token_time'] = time();
    return $_SESSION['csrf_token'];
}
