<?php
/**
 * M.M.G OUTLET - Database Configuration
 * Central database connection using PDO with prepared statements
 */

// Prevent direct access
if (!defined('MMG_ACCESS')) {
    define('MMG_ACCESS', true);
}

// Database credentials - UPDATE THESE FOR YOUR SERVER
$db_host = 'localhost';
$db_name = 'mmg_outlet';
$db_user = 'root';
$db_pass = '';
$db_charset = 'utf8mb4';

// DSN (Data Source Name)
$dsn = "mysql:host={$db_host};dbname={$db_name};charset={$db_charset}";

// PDO options for security and performance
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Throw exceptions on errors
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // Fetch associative arrays
    PDO::ATTR_EMULATE_PREPARES   => false,                  // Use real prepared statements
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES {$db_charset} COLLATE utf8mb4_unicode_ci"
];

try {
    $pdo = new PDO($dsn, $db_user, $db_pass, $options);
} catch (PDOException $e) {
    // Log error securely (don't expose details to users)
    error_log("[MMG OUTLET] Database connection failed: " . $e->getMessage());
    die("<div style='text-align:center;padding:50px;font-family:sans-serif;'>
        <h2 style='color:#FF5252;'>System Temporarily Unavailable</h2>
        <p>We're experiencing technical difficulties. Please try again later.</p>
    </div>");
}

/**
 * Helper function to get a single setting value
 */
function getSetting($key, $default = '') {
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1");
        $stmt->execute([$key]);
        $result = $stmt->fetch();
        return $result ? $result['setting_value'] : $default;
    } catch (PDOException $e) {
        return $default;
    }
}

/**
 * Helper function to update a setting
 */
function updateSetting($key, $value) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = ?");
        return $stmt->execute([$value, $key]);
    } catch (PDOException $e) {
        return false;
    }
}

/**
 * Helper function to execute prepared SELECT queries
 */
function dbQuery($sql, $params = []) {
    global $pdo;
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    } catch (PDOException $e) {
        error_log("[MMG OUTLET] Query error: " . $e->getMessage());
        return false;
    }
}

/**
 * Get a single row
 */
function dbFetch($sql, $params = []) {
    $stmt = dbQuery($sql, $params);
    return $stmt ? $stmt->fetch() : false;
}

/**
 * Get all rows
 */
function dbFetchAll($sql, $params = []) {
    $stmt = dbQuery($sql, $params);
    return $stmt ? $stmt->fetchAll() : [];
}

/**
 * Insert and return last insert ID
 */
function dbInsert($sql, $params = []) {
    global $pdo;
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $pdo->lastInsertId();
    } catch (PDOException $e) {
        error_log("[MMG OUTLET] Insert error: " . $e->getMessage());
        return false;
    }
}

/**
 * Execute update/delete
 */
function dbExecute($sql, $params = []) {
    global $pdo;
    try {
        $stmt = $pdo->prepare($sql);
        return $stmt->execute($params);
    } catch (PDOException $e) {
        error_log("[MMG OUTLET] Execute error: " . $e->getMessage());
        return false;
    }
}
