<?php
/**
 * M.M.G OUTLET - Global Functions
 * Shared utility functions for the entire application
 */

// Prevent direct access
if (!defined('MMG_ACCESS')) {
    define('MMG_ACCESS', true);
}

require_once __DIR__ . '/db.php';

// ============================================================
// SECURITY FUNCTIONS
// ============================================================

/**
 * Sanitize user input to prevent XSS
 */
function clean($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/**
 * Deep clean array values
 */
function cleanArray($array) {
    $cleaned = [];
    foreach ($array as $key => $value) {
        $cleaned[$key] = is_array($value) ? cleanArray($value) : clean($value);
    }
    return $cleaned;
}

/**
 * Generate CSRF token
 */
function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $_SESSION['csrf_token_time'] = time();
    }
    return $_SESSION['csrf_token'];
}

/**
 * Validate CSRF token
 */
function validateCsrfToken($token) {
    if (empty($token) || empty($_SESSION['csrf_token'])) {
        return false;
    }
    // Token expires after 1 hour
    if ((time() - ($_SESSION['csrf_token_time'] ?? 0)) > 3600) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Output CSRF token as hidden input
 */
function csrfField() {
    $token = generateCsrfToken();
    return '<input type="hidden" name="csrf_token" value="' . $token . '">';
}

/**
 * Redirect with optional flash message
 */
function redirect($url, $message = null, $type = 'success') {
    if ($message !== null) {
        $_SESSION['flash_message'] = $message;
        $_SESSION['flash_type'] = $type;
    }
    header("Location: {$url}");
    exit;
}

/**
 * Display flash message if exists
 */
function showFlash() {
    if (!empty($_SESSION['flash_message'])) {
        $message = clean($_SESSION['flash_message']);
        $type = clean($_SESSION['flash_type'] ?? 'success');
        $bgColors = [
            'success' => '#2E7D6F',
            'error'   => '#D32F2F',
            'warning' => '#FF9800',
            'info'    => '#2196F3'
        ];
        $bg = $bgColors[$type] ?? $bgColors['success'];
        echo "<div class='mmg-flash' style='background:{$bg};color:#fff;padding:16px 24px;border-radius:4px;margin-bottom:20px;font-family:Manrope,sans-serif;font-size:15px;position:relative;animation:slideIn 0.4s ease;'>
            <span>{$message}</span>
            <button onclick='this.parentElement.remove()' style='position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:#fff;font-size:18px;cursor:pointer;'>&times;</button>
        </div>";
        unset($_SESSION['flash_message'], $_SESSION['flash_type']);
    }
}

// ============================================================
// SESSION & AUTH FUNCTIONS
// ============================================================

/**
 * Start secure session
 */
function startSecureSession() {
    if (session_status() === PHP_SESSION_NONE) {
        ini_set('session.cookie_httponly', 1);
        ini_set('session.use_only_cookies', 1);
        ini_set('session.cookie_samesite', 'Strict');
        session_start();
    }
}

/**
 * Check if user is logged in as admin
 */
function isAdminLoggedIn() {
    startSecureSession();
    if (empty($_SESSION['admin_id']) || empty($_SESSION['admin_login_time'])) {
        return false;
    }
    // Session timeout check (30 minutes)
    $timeout = 1800;
    if ((time() - $_SESSION['admin_login_time']) > $timeout) {
        adminLogout();
        return false;
    }
    // Refresh login time
    $_SESSION['admin_login_time'] = time();
    return true;
}

/**
 * Require admin login
 */
function requireAdmin() {
    if (!isAdminLoggedIn()) {
        redirect('index.php?error=session_expired');
    }
}

/**
 * Admin logout
 */
function adminLogout() {
    startSecureSession();
    $_SESSION = [];
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 3600, '/');
    }
    session_destroy();
}

/**
 * Get current admin info
 */
function getCurrentAdmin() {
    startSecureSession();
    if (!empty($_SESSION['admin_id'])) {
        return dbFetch("SELECT * FROM admins WHERE id = ? AND is_active = 1 LIMIT 1", [$_SESSION['admin_id']]);
    }
    return false;
}

// ============================================================
// APPLICANT FUNCTIONS
// ============================================================

/**
 * Generate unique member ID
 */
function generateMemberId() {
    $prefix = 'MMG';
    $random = strtoupper(substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 5));
    $memberId = $prefix . '-' . $random;
    
    // Check if exists
    $exists = dbFetch("SELECT id FROM applicants WHERE member_id = ? LIMIT 1", [$memberId]);
    if ($exists) {
        return generateMemberId();
    }
    return $memberId;
}

/**
 * Get applicant by ID
 */
function getApplicant($id) {
    return dbFetch("SELECT * FROM applicants WHERE id = ? LIMIT 1", [$id]);
}

/**
 * Get all applicants with optional filters
 */
function getApplicants($status = null, $search = null, $plan = null, $limit = 20, $offset = 0) {
    $sql = "SELECT * FROM applicants WHERE 1=1";
    $params = [];
    
    if ($status) {
        $sql .= " AND status = ?";
        $params[] = $status;
    }
    if ($search) {
        $sql .= " AND (full_name LIKE ? OR phone_number LIKE ? OR email LIKE ? OR member_id LIKE ?)";
        $searchParam = "%{$search}%";
        $params = array_merge($params, [$searchParam, $searchParam, $searchParam, $searchParam]);
    }
    if ($plan) {
        $sql .= " AND membership_plan = ?";
        $params[] = $plan;
    }
    
    $sql .= " ORDER BY applied_at DESC LIMIT ? OFFSET ?";
    $params[] = (int)$limit;
    $params[] = (int)$offset;
    
    return dbFetchAll($sql, $params);
}

/**
 * Count applicants by status
 */
function countApplicants($status = null) {
    $sql = "SELECT COUNT(*) as total FROM applicants";
    $params = [];
    if ($status) {
        $sql .= " WHERE status = ?";
        $params[] = $status;
    }
    $result = dbFetch($sql, $params);
    return $result ? (int)$result['total'] : 0;
}

/**
 * Get total revenue
 */
function getTotalRevenue() {
    $result = dbFetch("SELECT COALESCE(SUM(plan_price), 0) as total FROM applicants WHERE status = 'Approved'");
    return $result ? (float)$result['total'] : 0;
}

/**
 * Get recent registrations
 */
function getRecentRegistrations($limit = 10) {
    return dbFetchAll("SELECT * FROM applicants ORDER BY applied_at DESC LIMIT ?", [(int)$limit]);
}

/**
 * Calculate membership end date based on plan
 */
function calculateEndDate($planName, $startDate = null) {
    $start = $startDate ? new DateTime($startDate) : new DateTime();
    
    switch ($planName) {
        case 'Daily Gym':
            $start->modify('+1 day');
            break;
        case 'One Month':
            $start->modify('+1 month');
            break;
        case 'Three Months':
            $start->modify('+3 months');
            break;
        case 'Registration Form':
        default:
            $start->modify('+1 year');
            break;
    }
    return $start->format('Y-m-d');
}

/**
 * Get plan duration in days
 */
function getPlanDuration($planName) {
    switch ($planName) {
        case 'Daily Gym': return 1;
        case 'One Month': return 30;
        case 'Three Months': return 90;
        default: return 365;
    }
}

// ============================================================
// FILE UPLOAD FUNCTIONS
// ============================================================

/**
 * Secure file upload
 */
function uploadFile($file, $directory, $allowedTypes = ['jpg', 'jpeg', 'png'], $maxSize = 2097152) {
    if (!isset($file['tmp_name']) || empty($file['tmp_name'])) {
        return ['success' => false, 'message' => 'No file uploaded'];
    }
    
    // Check upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors = [
            UPLOAD_ERR_INI_SIZE => 'File exceeds server limit',
            UPLOAD_ERR_FORM_SIZE => 'File exceeds form limit',
            UPLOAD_ERR_PARTIAL => 'File partially uploaded',
            UPLOAD_ERR_NO_FILE => 'No file uploaded'
        ];
        return ['success' => false, 'message' => $errors[$file['error']] ?? 'Upload error'];
    }
    
    // Validate file size
    if ($file['size'] > $maxSize) {
        return ['success' => false, 'message' => 'File size exceeds 2MB limit'];
    }
    
    // Validate file type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    $allowedMimes = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/jpg' => 'jpg'
    ];
    
    if (!isset($allowedMimes[$mimeType])) {
        return ['success' => false, 'message' => 'Invalid file type. Only JPG and PNG allowed'];
    }
    
    $extension = $allowedMimes[$mimeType];
    
    // Generate unique filename
    $filename = uniqid('mmg_', true) . '.' . $extension;
    $uploadPath = __DIR__ . '/../uploads/' . $directory . '/' . $filename;
    
    // Ensure directory exists
    if (!is_dir(__DIR__ . '/../uploads/' . $directory)) {
        mkdir(__DIR__ . '/../uploads/' . $directory, 0755, true);
    }
    
    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
        return ['success' => true, 'filename' => $filename, 'path' => 'uploads/' . $directory . '/' . $filename];
    }
    
    return ['success' => false, 'message' => 'Failed to save file'];
}

// ============================================================
// UTILITY FUNCTIONS
// ============================================================

/**
 * Format currency
 */
function formatCurrency($amount) {
    $symbol = getSetting('currency', '₦');
    return $symbol . number_format($amount, 2);
}

/**
 * Format date
 */
function formatDate($date, $format = 'M d, Y') {
    if (!$date) return 'N/A';
    $dt = new DateTime($date);
    return $dt->format($format);
}

/**
 * Format datetime
 */
function formatDateTime($datetime) {
    return formatDate($datetime, 'M d, Y h:i A');
}

/**
 * Get status badge HTML
 */
function statusBadge($status) {
    $colors = [
        'Pending'   => ['bg' => 'rgba(255,152,0,0.15)', 'color' => '#FF9800'],
        'Approved'  => ['bg' => 'rgba(46,125,111,0.15)', 'color' => '#2E7D6F'],
        'Rejected'  => ['bg' => 'rgba(211,47,47,0.15)', 'color' => '#D32F2F'],
        'Suspended' => ['bg' => 'rgba(89,89,89,0.2)', 'color' => '#595959'],
        'Active'    => ['bg' => 'rgba(46,125,111,0.15)', 'color' => '#2E7D6F'],
        'Expired'   => ['bg' => 'rgba(211,47,47,0.15)', 'color' => '#D32F2F'],
        'Paid'      => ['bg' => 'rgba(46,125,111,0.15)', 'color' => '#2E7D6F'],
    ];
    $style = $colors[$status] ?? $colors['Pending'];
    return "<span style='display:inline-block;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:500;background:{$style['bg']};color:{$style['color']};font-family:Manrope,sans-serif;'>{$status}</span>";
}

/**
 * Generate pagination HTML
 */
function pagination($currentPage, $totalPages, $baseUrl) {
    if ($totalPages <= 1) return '';
    
    $html = "<nav style='display:flex;justify-content:center;align-items:center;gap:8px;margin-top:30px;font-family:Manrope,sans-serif;'>";
    
    // Previous
    if ($currentPage > 1) {
        $html .= "<a href='{$baseUrl}&page=" . ($currentPage - 1) . "' style='padding:8px 16px;background:#151515;color:#fff;text-decoration:none;border-radius:4px;font-size:14px;border:1px solid rgba(255,255,255,0.06);transition:all 0.3s;' onmouseover=\"this.style.background='#FF5252'\" onmouseout=\"this.style.background='#151515'\">← Prev</a>";
    }
    
    // Pages
    $start = max(1, $currentPage - 2);
    $end = min($totalPages, $currentPage + 2);
    
    for ($i = $start; $i <= $end; $i++) {
        if ($i == $currentPage) {
            $html .= "<span style='padding:8px 16px;background:#FF5252;color:#fff;border-radius:4px;font-size:14px;font-weight:500;'>{$i}</span>";
        } else {
            $html .= "<a href='{$baseUrl}&page={$i}' style='padding:8px 16px;background:#151515;color:#C0C0C0;text-decoration:none;border-radius:4px;font-size:14px;border:1px solid rgba(255,255,255,0.06);transition:all 0.3s;' onmouseover=\"this.style.background='#FF5252';this.style.color='#fff'\" onmouseout=\"this.style.background='#151515';this.style.color='#C0C0C0'\">{$i}</a>";
        }
    }
    
    // Next
    if ($currentPage < $totalPages) {
        $html .= "<a href='{$baseUrl}&page=" . ($currentPage + 1) . "' style='padding:8px 16px;background:#151515;color:#fff;text-decoration:none;border-radius:4px;font-size:14px;border:1px solid rgba(255,255,255,0.06);transition:all 0.3s;' onmouseover=\"this.style.background='#FF5252'\" onmouseout=\"this.style.background='#151515'\">Next →</a>";
    }
    
    $html .= "</nav>";
    return $html;
}

/**
 * Log admin action
 */
function logAction($adminId, $action, $details = '') {
    error_log("[MMG OUTLET] Admin #{$adminId} | {$action} | {$details} | " . date('Y-m-d H:i:s'));
}

/**
 * Nigerian states for dropdown
 */
function getNigerianStates() {
    return [
        'Abia', 'Adamawa', 'Akwa Ibom', 'Anambra', 'Bauchi', 'Bayelsa', 'Benue',
        'Borno', 'Cross River', 'Delta', 'Ebonyi', 'Edo', 'Ekiti', 'Enugu', 'FCT',
        'Gombe', 'Imo', 'Jigawa', 'Kaduna', 'Kano', 'Katsina', 'Kebbi', 'Kogi',
        'Kwara', 'Lagos', 'Nasarawa', 'Niger', 'Ogun', 'Ondo', 'Osun', 'Oyo',
        'Plateau', 'Rivers', 'Sokoto', 'Taraba', 'Yobe', 'Zamfara'
    ];
}

/**
 * Membership plans
 */
function getMembershipPlans() {
    return [
        'Registration Form' => ['price' => 1000, 'duration' => 'One-time'],
        'Daily Gym'         => ['price' => 3000, 'duration' => '1 Day'],
        'One Month'         => ['price' => 20000, 'duration' => '30 Days'],
        'Three Months'      => ['price' => 60000, 'duration' => '90 Days'],
    ];
}
