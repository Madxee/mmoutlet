<?php
/**
 * M.M.G OUTLET - Public Header Template
 * Included on all public-facing pages
 */

// Prevent direct access
if (!defined('MMG_ACCESS')) {
    die('Direct access not permitted');
}

require_once __DIR__ . '/functions.php';
startSecureSession();

$pageTitle = $pageTitle ?? 'M.M.G OUTLET';
$gymName = getSetting('gym_name', 'M.M.G OUTLET');
$gymLogo = getSetting('gym_logo', 'assets/images/logo.png');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo clean($gymName); ?> - Strength • Discipline • Fitness. Premium gym and fitness center in Kano, Nigeria.">
    <meta name="keywords" content="gym, fitness, workout, bodybuilding, Kano, Nigeria, M.M.G OUTLET">
    <meta name="author" content="M.M.G OUTLET">
    <meta name="theme-color" content="#050505">
    <title><?php echo clean($pageTitle); ?> | <?php echo clean($gymName); ?></title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="assets/images/favicon-32x32.png">
    <link rel="apple-touch-icon" href="assets/images/apple-touch-icon.png">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Manrope:wght@300;400;500;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Styles -->
    <link rel="stylesheet" href="assets/css/style.css?v=<?php echo time(); ?>">

    <!-- GSAP -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js"></script>
</head>
<body>
    <!-- Navigation -->
    <nav class="mmg-navbar" id="mainNav">
        <div class="mmg-nav-container">
            <a href="index.php" class="mmg-nav-logo">
                <img src="<?php echo clean($gymLogo); ?>" alt="<?php echo clean($gymName); ?>" class="mmg-logo-img">
            </a>
            <button class="mmg-nav-toggle" id="navToggle" aria-label="Toggle navigation">
                <span class="mmg-hamburger-line"></span>
                <span class="mmg-hamburger-line"></span>
                <span class="mmg-hamburger-line"></span>
            </button>
            <div class="mmg-nav-menu" id="navMenu">
                <a href="index.php" class="mmg-nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">Home</a>
                <a href="about.php" class="mmg-nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'about.php' ? 'active' : ''; ?>">About</a>
                <a href="membership.php" class="mmg-nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'membership.php' ? 'active' : ''; ?>">Membership</a>
                <a href="apply.php" class="mmg-nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'apply.php' ? 'active' : ''; ?>">Apply</a>
                <a href="contact.php" class="mmg-nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'contact.php' ? 'active' : ''; ?>">Contact</a>
            </div>
        </div>
    </nav>

    <!-- Flash Messages -->
    <div class="mmg-flash-container" id="flashContainer">
        <?php showFlash(); ?>
    </div>
