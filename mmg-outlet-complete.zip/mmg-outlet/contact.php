<?php
/**
 * M.M.G OUTLET - Contact Page
 */

define('MMG_ACCESS', true);
$pageTitle = 'Contact Us';
require_once 'includes/header.php';

$gymName = getSetting('gym_name', 'M.M.G OUTLET');
$gymAddress = getSetting('gym_address', '305B Tudun Yola Opposite AMK Petrol Station, Kano, Kano State, Nigeria');
$gymPhone = getSetting('gym_phone', '+234 912 717 1928');
$gymEmail = getSetting('gym_email', 'info@mmgoutlet.com');
$whatsapp = getSetting('whatsapp_link', 'https://wa.me/2349127171928');
$instagram = getSetting('instagram_link', '#');
$facebook = getSetting('facebook_link', '#');
$twitter = getSetting('twitter_link', '#');
?>

<section class="mmg-about-hero">
    <div class="mmg-container text-center">
        <span class="mmg-section-label mmg-reveal">GET IN TOUCH</span>
        <h1 class="mmg-about-hero-title mmg-reveal mmg-reveal-delay-1">CONTACT<br>US</h1>
        <p class="mmg-section-text mmg-reveal mmg-reveal-delay-2" style="margin:20px auto 0;max-width:500px;">
            Have questions? We're here to help. Reach out to us through any of the channels below.
        </p>
    </div>
</section>

<div class="mmg-separator"></div>

<section class="mmg-section mmg-section-dark">
    <div class="mmg-container">
        <div class="row g-5">
            <!-- Contact Info Cards -->
            <div class="col-lg-4">
                <div class="mmg-contact-card mmg-reveal" style="background:var(--dark-card);border:1px solid var(--border-subtle);border-radius:4px;">
                    <div class="mmg-contact-icon">
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/></svg>
                    </div>
                    <h3 class="mmg-contact-title">Phone / WhatsApp</h3>
                    <p class="mmg-contact-info"><?php echo clean($gymPhone); ?></p>
                    <a href="<?php echo clean($whatsapp); ?>" target="_blank" class="mmg-link-red" style="margin-top:12px;display:inline-block;">
                        Chat on WhatsApp
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                    </a>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="mmg-contact-card mmg-reveal mmg-reveal-delay-1" style="background:var(--dark-card);border:1px solid var(--border-subtle);border-radius:4px;">
                    <div class="mmg-contact-icon">
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                    </div>
                    <h3 class="mmg-contact-title">Email</h3>
                    <p class="mmg-contact-info"><?php echo clean($gymEmail); ?></p>
                    <a href="mailto:<?php echo clean($gymEmail); ?>" class="mmg-link-red" style="margin-top:12px;display:inline-block;">
                        Send Email
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                    </a>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="mmg-contact-card mmg-reveal mmg-reveal-delay-2" style="background:var(--dark-card);border:1px solid var(--border-subtle);border-radius:4px;">
                    <div class="mmg-contact-icon">
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    </div>
                    <h3 class="mmg-contact-title">Location</h3>
                    <p class="mmg-contact-info"><?php echo clean($gymAddress); ?></p>
                    <a href="https://maps.google.com/?q=<?php echo urlencode($gymAddress); ?>" target="_blank" class="mmg-link-red" style="margin-top:12px;display:inline-block;">
                        Get Directions
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Google Map -->
<section class="mmg-section-charcoal" style="padding:0;">
    <div class="mmg-map-container mmg-reveal" style="height:400px;">
        <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15617.5!2d8.5!3d12.0!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTLCsDAwJzAwLjAiTiA4wrAzMCcwMC4wIkU!5e0!3m2!1sen!2sng!4v1" 
            width="100%" 
            height="100%" 
            style="border:0;filter:grayscale(100%) invert(92%);" 
            allowfullscreen="" 
            loading="lazy" 
            referrerpolicy="no-referrer-when-downgrade">
        </iframe>
    </div>
</section>

<!-- Opening Hours & Social -->
<section class="mmg-section mmg-section-dark">
    <div class="mmg-container">
        <div class="row g-5">
            <div class="col-lg-6 mmg-reveal">
                <span class="mmg-section-label mmg-section-label-red">VISIT US</span>
                <h2 class="mmg-section-title" style="font-size:40px;">OPENING<br>HOURS</h2>
                <div style="margin-top:24px;">
                    <div style="display:flex;justify-content:space-between;padding:14px 0;border-bottom:1px solid var(--border-subtle);">
                        <span style="color:var(--ice-gray);font-size:15px;">Monday — Friday</span>
                        <span style="color:var(--white);font-size:15px;font-weight:500;">5:00 AM — 10:00 PM</span>
                    </div>
                    <div style="display:flex;justify-content:space-between;padding:14px 0;border-bottom:1px solid var(--border-subtle);">
                        <span style="color:var(--ice-gray);font-size:15px;">Saturday</span>
                        <span style="color:var(--white);font-size:15px;font-weight:500;">6:00 AM — 9:00 PM</span>
                    </div>
                    <div style="display:flex;justify-content:space-between;padding:14px 0;border-bottom:1px solid var(--border-subtle);">
                        <span style="color:var(--ice-gray);font-size:15px;">Sunday</span>
                        <span style="color:var(--white);font-size:15px;font-weight:500;">7:00 AM — 8:00 PM</span>
                    </div>
                    <div style="display:flex;justify-content:space-between;padding:14px 0;">
                        <span style="color:var(--coral-red);font-size:15px;font-weight:500;">Grand Opening</span>
                        <span style="color:var(--gold-accent);font-size:15px;font-weight:500;">Sunday, 15th June — 10:00 AM</span>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-6 mmg-reveal mmg-reveal-delay-1">
                <span class="mmg-section-label">FOLLOW US</span>
                <h2 class="mmg-section-title" style="font-size:40px;">STAY<br>CONNECTED</h2>
                <p class="mmg-section-text" style="margin-top:16px;">
                    Follow us on social media for workout tips, motivation, facility updates, and exclusive member content.
                </p>
                <div style="display:flex;gap:16px;margin-top:32px;">
                    <a href="<?php echo clean($instagram); ?>" target="_blank" rel="noopener noreferrer" style="width:56px;height:56px;background:var(--dark-card);border:1px solid var(--border-subtle);display:flex;align-items:center;justify-content:center;color:var(--white);transition:var(--transition-smooth);" onmouseover="this.style.background='var(--coral-red)';this.style.borderColor='var(--coral-red)'" onmouseout="this.style.background='var(--dark-card)';this.style.borderColor='var(--border-subtle)'">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
                    </a>
                    <a href="<?php echo clean($facebook); ?>" target="_blank" rel="noopener noreferrer" style="width:56px;height:56px;background:var(--dark-card);border:1px solid var(--border-subtle);display:flex;align-items:center;justify-content:center;color:var(--white);transition:var(--transition-smooth);" onmouseover="this.style.background='var(--coral-red)';this.style.borderColor='var(--coral-red)'" onmouseout="this.style.background='var(--dark-card)';this.style.borderColor='var(--border-subtle)'">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/></svg>
                    </a>
                    <a href="<?php echo clean($twitter); ?>" target="_blank" rel="noopener noreferrer" style="width:56px;height:56px;background:var(--dark-card);border:1px solid var(--border-subtle);display:flex;align-items:center;justify-content:center;color:var(--white);transition:var(--transition-smooth);" onmouseover="this.style.background='var(--coral-red)';this.style.borderColor='var(--coral-red)'" onmouseout="this.style.background='var(--dark-card)';this.style.borderColor='var(--border-subtle)'">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                    </a>
                    <a href="<?php echo clean($whatsapp); ?>" target="_blank" rel="noopener noreferrer" style="width:56px;height:56px;background:var(--dark-card);border:1px solid var(--border-subtle);display:flex;align-items:center;justify-content:center;color:var(--white);transition:var(--transition-smooth);" onmouseover="this.style.background='#25D366';this.style.borderColor='#25D366'" onmouseout="this.style.background='var(--dark-card)';this.style.borderColor='var(--border-subtle)'">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
