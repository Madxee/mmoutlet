<?php
/**
 * M.M.G OUTLET - Homepage
 * Grand opening ceremony landing page
 */

define('MMG_ACCESS', true);
$pageTitle = 'Open Grand Ceremony';
require_once 'includes/header.php';

$gymName = getSetting('gym_name', 'M.M.G OUTLET');
$gymMotto = getSetting('gym_motto', 'Strength • Discipline • Fitness');
$gymAddress = getSetting('gym_address', '305B Tudun Yola Opposite AMK Petrol Station, Kano, Kano State, Nigeria');
$gymPhone = getSetting('gym_phone', '+234 912 717 1928');
$whatsapp = getSetting('whatsapp_link', 'https://wa.me/2349127171928');

// Get pricing from settings
$regPrice = getSetting('registration_form_price', '1000');
$dailyPrice = getSetting('daily_gym_price', '3000');
$monthPrice = getSetting('one_month_price', '20000');
$quarterPrice = getSetting('three_month_price', '60000');
?>

<!-- ============================================================ -->
<!-- HERO SECTION -->
<!-- ============================================================ -->
<section class="mmg-hero" id="home">
    <div class="mmg-hero-bg">
        <img src="assets/images/hero-bg.jpg" alt="M.M.G OUTLET Gym Interior">
    </div>
    <div class="mmg-hero-overlay"></div>
    <div class="mmg-hero-content">
        <h1 class="mmg-hero-title">OPEN GRAND CEREMONY</h1>
        <p class="mmg-hero-subtitle">A New Era Of Fitness, Strength And Transformation</p>
        <div class="mmg-hero-actions">
            <a href="apply.php" class="mmg-btn mmg-btn-outline">Apply Now</a>
            <a href="membership.php" class="mmg-btn mmg-btn-primary">Join Membership</a>
            <a href="contact.php" class="mmg-btn mmg-btn-outline">Contact Us</a>
        </div>
    </div>
</section>

<div class="mmg-separator"></div>

<!-- ============================================================ -->
<!-- ABOUT SECTION -->
<!-- ============================================================ -->
<section class="mmg-section mmg-section-dark" id="about">
    <div class="mmg-container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <div class="overflow-hidden">
                    <img src="assets/images/gym-about.jpg" alt="M.M.G OUTLET Premium Gym Facility" class="mmg-about-image">
                </div>
            </div>
            <div class="col-lg-6">
                <span class="mmg-section-label mmg-reveal">ABOUT M.M.G OUTLET</span>
                <h2 class="mmg-section-title mmg-reveal mmg-reveal-delay-1">BUILT FOR<br>THE SERIOUS</h2>
                <p class="mmg-section-text mmg-reveal mmg-reveal-delay-2">
                    M.M.G OUTLET is a professional fitness and transformation center spanning over 25,000 square feet of world-class training space. Our facility features premium strength and conditioning equipment, dedicated functional training zones, and expert personal trainers committed to helping you achieve your fitness goals.
                </p>
                <p class="mmg-section-text mmg-reveal mmg-reveal-delay-2" style="margin-top: 16px;">
                    From bodybuilding to CrossFit, yoga to high-intensity interval training, we provide the tools, environment, and community you need to push your limits and transform your body and mind. Our motto — Strength, Discipline, Fitness — drives everything we do.
                </p>
                <div class="mt-4 mmg-reveal mmg-reveal-delay-3">
                    <a href="about.php" class="mmg-link-red">
                        Learn More
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ============================================================ -->
<!-- MEMBERSHIP PLANS SECTION -->
<!-- ============================================================ -->
<section class="mmg-section mmg-section-charcoal" id="membership">
    <div class="mmg-container">
        <div class="text-center mb-5">
            <span class="mmg-section-label mmg-reveal">MEMBERSHIP PLANS</span>
            <h2 class="mmg-section-title mmg-reveal mmg-reveal-delay-1">INVEST IN<br>YOURSELF</h2>
        </div>
        <div class="row g-4">
            <!-- Registration Form -->
            <div class="col-lg-3 col-md-6 mmg-reveal mmg-reveal-delay-1">
                <div class="mmg-pricing-card">
                    <h3 class="mmg-pricing-name">Registration Form</h3>
                    <div class="mmg-pricing-price" data-price-default="₦<?php echo number_format($regPrice); ?>" data-price-hover="₦<?php echo number_format($regPrice); ?>" data-scramble-chars="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ">₦<?php echo number_format($regPrice); ?></div>
                    <span class="mmg-pricing-duration">One-time Fee</span>
                    <p class="mmg-pricing-desc">Complete your registration to become a member of M.M.G OUTLET fitness community.</p>
                    <a href="apply.php?plan=Registration+Form" class="mmg-btn mmg-btn-outline-red" style="width:100%;text-align:center;padding:10px;font-size:12px;">Select Plan</a>
                </div>
            </div>
            <!-- Daily Gym -->
            <div class="col-lg-3 col-md-6 mmg-reveal mmg-reveal-delay-2">
                <div class="mmg-pricing-card">
                    <h3 class="mmg-pricing-name">Daily Gym</h3>
                    <div class="mmg-pricing-price" data-price-default="₦<?php echo number_format($dailyPrice); ?>" data-price-hover="₦<?php echo number_format($dailyPrice); ?>" data-scramble-chars="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ">₦<?php echo number_format($dailyPrice); ?></div>
                    <span class="mmg-pricing-duration">1 Day Access</span>
                    <p class="mmg-pricing-desc">Full day access to all gym facilities, equipment, and training zones for a single day.</p>
                    <a href="apply.php?plan=Daily+Gym" class="mmg-btn mmg-btn-outline-red" style="width:100%;text-align:center;padding:10px;font-size:12px;">Select Plan</a>
                </div>
            </div>
            <!-- One Month -->
            <div class="col-lg-3 col-md-6 mmg-reveal mmg-reveal-delay-3">
                <div class="mmg-pricing-card">
                    <h3 class="mmg-pricing-name">One Month</h3>
                    <div class="mmg-pricing-price" data-price-default="₦<?php echo number_format($monthPrice); ?>" data-price-hover="₦<?php echo number_format($monthPrice); ?>" data-scramble-chars="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ">₦<?php echo number_format($monthPrice); ?></div>
                    <span class="mmg-pricing-duration">30 Days</span>
                    <p class="mmg-pricing-desc">Unlimited access for 30 days. Includes free fitness assessment and workout plan.</p>
                    <a href="apply.php?plan=One+Month" class="mmg-btn mmg-btn-outline-red" style="width:100%;text-align:center;padding:10px;font-size:12px;">Select Plan</a>
                </div>
            </div>
            <!-- Three Months -->
            <div class="col-lg-3 col-md-6 mmg-reveal mmg-reveal-delay-4">
                <div class="mmg-pricing-card">
                    <h3 class="mmg-pricing-name">Three Months</h3>
                    <div class="mmg-pricing-price" data-price-default="₦<?php echo number_format($quarterPrice); ?>" data-price-hover="₦<?php echo number_format($quarterPrice); ?>" data-scramble-chars="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ">₦<?php echo number_format($quarterPrice); ?></div>
                    <span class="mmg-pricing-duration">90 Days</span>
                    <p class="mmg-pricing-desc">Best value! 3 months of unlimited access plus 2 free personal training sessions.</p>
                    <a href="apply.php?plan=Three+Months" class="mmg-btn mmg-btn-outline-red" style="width:100%;text-align:center;padding:10px;font-size:12px;">Select Plan</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ============================================================ -->
<!-- SPECIAL OFFERS SECTION -->
<!-- ============================================================ -->
<section class="mmg-section mmg-section-dark" id="offers">
    <div class="mmg-container">
        <div class="text-center mb-5">
            <span class="mmg-section-label mmg-section-label-red mmg-reveal">EXCLUSIVE</span>
            <h2 class="mmg-section-title mmg-reveal mmg-reveal-delay-1">SPECIAL OFFERS</h2>
        </div>
        <div class="row g-4">
            <div class="col-lg col-md-4 col-6 mmg-reveal mmg-reveal-delay-1">
                <div class="mmg-offer-card" style="height:100%;">
                    <div class="mmg-offer-icon">
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
                    </div>
                    <h3 class="mmg-offer-title">Free Gym Tour</h3>
                    <p class="mmg-offer-desc">Explore our world-class facilities with a complimentary guided tour.</p>
                </div>
            </div>
            <div class="col-lg col-md-4 col-6 mmg-reveal mmg-reveal-delay-2">
                <div class="mmg-offer-card" style="height:100%;">
                    <div class="mmg-offer-icon">
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/><line x1="12" y1="22" x2="12" y2="7"/><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/></svg>
                    </div>
                    <h3 class="mmg-offer-title">Exclusive Discounts</h3>
                    <p class="mmg-offer-desc">Grand opening special pricing for founding members only.</p>
                </div>
            </div>
            <div class="col-lg col-md-4 col-6 mmg-reveal mmg-reveal-delay-3">
                <div class="mmg-offer-card" style="height:100%;">
                    <div class="mmg-offer-icon">
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    </div>
                    <h3 class="mmg-offer-title">Free Fitness Consultation</h3>
                    <p class="mmg-offer-desc">One-on-one session with our expert trainers to plan your goals.</p>
                </div>
            </div>
            <div class="col-lg col-md-4 col-6 mmg-reveal mmg-reveal-delay-1">
                <div class="mmg-offer-card" style="height:100%;">
                    <div class="mmg-offer-icon">
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8h1a4 4 0 0 1 0 8h-1"/><path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"/><line x1="6" y1="1" x2="6" y2="4"/><line x1="10" y1="1" x2="10" y2="4"/><line x1="14" y1="1" x2="14" y2="4"/></svg>
                    </div>
                    <h3 class="mmg-offer-title">Refreshments & Giveaways</h3>
                    <p class="mmg-offer-desc">Complimentary drinks and exciting prizes at our grand opening.</p>
                </div>
            </div>
            <div class="col-lg col-md-4 col-6 mmg-reveal mmg-reveal-delay-2">
                <div class="mmg-offer-card" style="height:100%;">
                    <div class="mmg-offer-icon">
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                    </div>
                    <h3 class="mmg-offer-title">Meet Professional Trainers</h3>
                    <p class="mmg-offer-desc">Get to know our certified fitness experts and their specializations.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ============================================================ -->
<!-- OPENING EVENT SECTION -->
<!-- ============================================================ -->
<section class="mmg-event-section" id="event">
    <div class="mmg-event-bg">
        <img src="assets/images/gym-exterior.jpg" alt="M.M.G OUTLET Building">
    </div>
    <div class="mmg-event-overlay"></div>
    <div class="mmg-container">
        <div class="row">
            <div class="col-lg-6 mmg-event-content">
                <span class="mmg-section-label mmg-section-label-red mmg-reveal">GRAND OPENING</span>
                <h2 class="mmg-section-title mmg-reveal mmg-reveal-delay-1">JOIN US<br>THIS SUNDAY</h2>
                <div class="mmg-reveal mmg-reveal-delay-2">
                    <p class="mmg-event-date">Sunday, 15th June</p>
                    <p class="mmg-event-time">10:00AM Prompt</p>
                    <p class="mmg-event-venue"><?php echo clean($gymAddress); ?></p>
                </div>
                <div class="mt-4 mmg-reveal mmg-reveal-delay-3">
                    <a href="contact.php" class="mmg-btn mmg-btn-primary">ADD TO CALENDAR</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ============================================================ -->
<!-- GALLERY SECTION -->
<!-- ============================================================ -->
<section class="mmg-section mmg-section-charcoal" id="gallery">
    <div class="mmg-container mb-4">
        <div class="text-center">
            <span class="mmg-section-label mmg-reveal">OUR FACILITY</span>
            <h2 class="mmg-section-title mmg-reveal mmg-reveal-delay-1">GALLERY</h2>
        </div>
    </div>
    <div class="mmg-gallery mmg-reveal">
        <div class="mmg-gallery-track">
            <div class="mmg-gallery-item"><img src="assets/images/gallery-1.jpg" alt="Weight Training"></div>
            <div class="mmg-gallery-item"><img src="assets/images/gallery-2.jpg" alt="Boxing Area"></div>
            <div class="mmg-gallery-item"><img src="assets/images/gallery-3.jpg" alt="Personal Training"></div>
            <div class="mmg-gallery-item"><img src="assets/images/gallery-4.jpg" alt="Cardio Zone"></div>
            <div class="mmg-gallery-item"><img src="assets/images/gym-about.jpg" alt="Equipment Area"></div>
            <div class="mmg-gallery-item"><img src="assets/images/hero-bg.jpg" alt="Main Floor"></div>
            <!-- Duplicate for seamless loop -->
            <div class="mmg-gallery-item"><img src="assets/images/gallery-1.jpg" alt="Weight Training"></div>
            <div class="mmg-gallery-item"><img src="assets/images/gallery-2.jpg" alt="Boxing Area"></div>
            <div class="mmg-gallery-item"><img src="assets/images/gallery-3.jpg" alt="Personal Training"></div>
            <div class="mmg-gallery-item"><img src="assets/images/gallery-4.jpg" alt="Cardio Zone"></div>
            <div class="mmg-gallery-item"><img src="assets/images/gym-about.jpg" alt="Equipment Area"></div>
            <div class="mmg-gallery-item"><img src="assets/images/hero-bg.jpg" alt="Main Floor"></div>
        </div>
    </div>
</section>

<!-- ============================================================ -->
<!-- CTA / APPLY SECTION -->
<!-- ============================================================ -->
<section class="mmg-section mmg-section-dark" id="apply" style="text-align:center;">
    <div class="mmg-container">
        <span class="mmg-section-label mmg-section-label-red mmg-reveal">READY TO START?</span>
        <h2 class="mmg-section-title mmg-reveal mmg-reveal-delay-1">YOUR TRANSFORMATION<br>BEGINS NOW</h2>
        <p class="mmg-section-text mmg-reveal mmg-reveal-delay-2" style="margin:0 auto 40px;">
            Join M.M.G OUTLET today and take the first step towards a stronger, healthier you. 
            Our team is ready to guide you on your fitness journey.
        </p>
        <div class="mmg-reveal mmg-reveal-delay-3">
            <a href="apply.php" class="mmg-btn mmg-btn-primary" style="font-size:16px;padding:16px 48px;">APPLY FOR MEMBERSHIP</a>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
