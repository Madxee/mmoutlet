<?php
/**
 * M.M.G OUTLET - Online Application Form
 * Membership registration with file uploads
 */

define('MMG_ACCESS', true);
require_once 'includes/functions.php';
require_once 'includes/csrf.php';
startSecureSession();

$pageTitle = 'Apply for Membership';
$error = '';
$success = '';

// Get pre-selected plan from URL
$selectedPlan = $_GET['plan'] ?? '';
$plans = getMembershipPlans();
$states = getNigerianStates();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF
    if (!csrf_validate()) {
        $error = 'Invalid security token. Please refresh and try again.';
    } else {
        // Collect and sanitize inputs
        $fullName     = trim($_POST['full_name'] ?? '');
        $phone        = trim($_POST['phone_number'] ?? '');
        $whatsapp     = trim($_POST['whatsapp_number'] ?? '');
        $email        = trim($_POST['email'] ?? '');
        $gender       = $_POST['gender'] ?? '';
        $dob          = $_POST['date_of_birth'] ?? '';
        $address      = trim($_POST['address'] ?? '');
        $state        = $_POST['state'] ?? '';
        $occupation   = trim($_POST['occupation'] ?? '');
        $emergency    = trim($_POST['emergency_contact'] ?? '');
        $plan         = $_POST['membership_plan'] ?? '';
        $medical      = trim($_POST['medical_condition'] ?? '');
        $username     = trim($_POST['username'] ?? '');
        $password     = $_POST['password'] ?? '';
        
        // Validation
        if (empty($fullName) || empty($phone) || empty($gender) || empty($plan) || empty($username) || empty($password)) {
            $error = 'Please fill in all required fields (marked with *).';
        } elseif (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address.';
        } elseif (strlen($password) < 6) {
            $error = 'Password must be at least 6 characters long.';
        } elseif (strlen($username) < 3) {
            $error = 'Username must be at least 3 characters long.';
        } else {
            // Check if username exists
            $existing = dbFetch("SELECT id FROM applicants WHERE username = ? LIMIT 1", [$username]);
            if ($existing) {
                $error = 'Username is already taken. Please choose another.';
            } else {
                // Check if email exists (if provided)
                if (!empty($email)) {
                    $existingEmail = dbFetch("SELECT id FROM applicants WHERE email = ? LIMIT 1", [$email]);
                    if ($existingEmail) {
                        $error = 'Email address is already registered.';
                    }
                }
                
                if (empty($error)) {
                    // Handle file uploads
                    $passportPhoto = null;
                    $meansOfId = null;
                    
                    if (!empty($_FILES['passport_photo']['tmp_name'])) {
                        $result = uploadFile($_FILES['passport_photo'], 'passports');
                        if ($result['success']) {
                            $passportPhoto = $result['path'];
                        } else {
                            $error = 'Passport photo: ' . $result['message'];
                        }
                    }
                    
                    if (empty($error) && !empty($_FILES['means_of_id']['tmp_name'])) {
                        $result = uploadFile($_FILES['means_of_id'], 'ids');
                        if ($result['success']) {
                            $meansOfId = $result['path'];
                        } else {
                            $error = 'Means of ID: ' . $result['message'];
                        }
                    }
                    
                    if (empty($error)) {
                        // Get plan price
                        $planPrice = $plans[$plan]['price'] ?? 0;
                        
                        // Hash password
                        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                        
                        // Insert applicant
                        $applicantId = dbInsert(
                            "INSERT INTO applicants 
                            (full_name, phone_number, whatsapp_number, email, gender, date_of_birth, 
                             address, state, occupation, emergency_contact, membership_plan, plan_price,
                             passport_photo, means_of_id, medical_condition, username, password_hash, status) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')",
                            [$fullName, $phone, $whatsapp, $email, $gender, $dob, $address, $state, 
                             $occupation, $emergency, $plan, $planPrice, $passportPhoto, $meansOfId, 
                             $medical, $username, $passwordHash]
                        );
                        
                        if ($applicantId) {
                            // Create payment record
                            dbInsert(
                                "INSERT INTO payments (applicant_id, plan_name, amount, payment_status) 
                                 VALUES (?, ?, ?, 'Pending')",
                                [$applicantId, $plan, $planPrice]
                            );
                            
                            // Create notification for admin
                            dbInsert(
                                "INSERT INTO notifications (title, message, type, related_type, related_id) 
                                 VALUES (?, ?, 'info', 'applicant', ?)",
                                ["New Application: {$fullName}", "A new membership application has been received from {$fullName} for {$plan} plan.", $applicantId]
                            );
                            
                            $success = 'Application submitted successfully! Your application is now pending review. You will be contacted once approved.';
                            
                            // Clear form
                            $selectedPlan = '';
                        } else {
                            $error = 'Failed to submit application. Please try again.';
                        }
                    }
                }
            }
        }
    }
}

require_once 'includes/header.php';
?>

<section class="mmg-about-hero">
    <div class="mmg-container text-center">
        <span class="mmg-section-label mmg-reveal">JOIN THE FAMILY</span>
        <h1 class="mmg-about-hero-title mmg-reveal mmg-reveal-delay-1">APPLICATION<br>FORM</h1>
        <p class="mmg-section-text mmg-reveal mmg-reveal-delay-2" style="margin:20px auto 0;max-width:600px;">
            Fill out the form below to apply for membership at M.M.G OUTLET. All fields marked with * are required.
        </p>
    </div>
</section>

<div class="mmg-separator"></div>

<section class="mmg-form-section">
    <div class="mmg-container">
        <?php if ($error): ?>
        <div class="alert" style="background:rgba(211,47,47,0.15);border:1px solid rgba(211,47,47,0.3);color:#FF5252;padding:16px 24px;border-radius:8px;margin-bottom:30px;font-family:var(--font-body);font-size:15px;">
            <?php echo clean($error); ?>
        </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
        <div class="alert" style="background:rgba(46,125,111,0.15);border:1px solid rgba(46,125,111,0.3);color:#2E7D6F;padding:16px 24px;border-radius:8px;margin-bottom:30px;font-family:var(--font-body);font-size:15px;">
            <?php echo clean($success); ?>
            <div class="mt-3">
                <a href="index.php" class="mmg-btn mmg-btn-primary" style="font-size:13px;padding:10px 24px;">Return to Home</a>
            </div>
        </div>
        <?php else: ?>
        
        <form method="POST" action="apply.php" enctype="multipart/form-data" id="applicationForm">
            <?php echo csrfField(); ?>
            
            <div class="row g-4">
                <!-- Left Column - Personal Info -->
                <div class="col-lg-6">
                    <h3 style="font-family:var(--font-heading);font-size:24px;color:var(--white);margin-bottom:24px;text-transform:uppercase;">Personal Information</h3>
                    
                    <div class="mmg-form-group">
                        <label class="mmg-form-label">Full Name *</label>
                        <input type="text" name="full_name" class="mmg-form-input" placeholder="Enter your full name" required 
                               value="<?php echo clean($_POST['full_name'] ?? ''); ?>">
                    </div>
                    
                    <div class="mmg-form-group">
                        <label class="mmg-form-label">Phone Number *</label>
                        <input type="tel" name="phone_number" class="mmg-form-input" placeholder="e.g. 08012345678" required
                               value="<?php echo clean($_POST['phone_number'] ?? ''); ?>">
                    </div>
                    
                    <div class="mmg-form-group">
                        <label class="mmg-form-label">WhatsApp Number</label>
                        <input type="tel" name="whatsapp_number" class="mmg-form-input" placeholder="e.g. 08012345678"
                               value="<?php echo clean($_POST['whatsapp_number'] ?? ''); ?>">
                    </div>
                    
                    <div class="mmg-form-group">
                        <label class="mmg-form-label">Email Address</label>
                        <input type="email" name="email" class="mmg-form-input" placeholder="your@email.com"
                               value="<?php echo clean($_POST['email'] ?? ''); ?>">
                    </div>
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="mmg-form-group">
                                <label class="mmg-form-label">Gender *</label>
                                <select name="gender" class="mmg-form-select" required>
                                    <option value="">Select Gender</option>
                                    <option value="Male" <?php echo ($_POST['gender'] ?? '') === 'Male' ? 'selected' : ''; ?>>Male</option>
                                    <option value="Female" <?php echo ($_POST['gender'] ?? '') === 'Female' ? 'selected' : ''; ?>>Female</option>
                                    <option value="Other" <?php echo ($_POST['gender'] ?? '') === 'Other' ? 'selected' : ''; ?>>Other</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mmg-form-group">
                                <label class="mmg-form-label">Date of Birth</label>
                                <input type="date" name="date_of_birth" class="mmg-form-input"
                                       value="<?php echo clean($_POST['date_of_birth'] ?? ''); ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="mmg-form-group">
                        <label class="mmg-form-label">Address</label>
                        <textarea name="address" class="mmg-form-textarea" placeholder="Enter your residential address"><?php echo clean($_POST['address'] ?? ''); ?></textarea>
                    </div>
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="mmg-form-group">
                                <label class="mmg-form-label">State</label>
                                <select name="state" class="mmg-form-select">
                                    <option value="">Select State</option>
                                    <?php foreach ($states as $st): ?>
                                    <option value="<?php echo $st; ?>" <?php echo ($_POST['state'] ?? '') === $st ? 'selected' : ''; ?>><?php echo $st; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mmg-form-group">
                                <label class="mmg-form-label">Occupation</label>
                                <input type="text" name="occupation" class="mmg-form-input" placeholder="Your occupation"
                                       value="<?php echo clean($_POST['occupation'] ?? ''); ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="mmg-form-group">
                        <label class="mmg-form-label">Emergency Contact</label>
                        <input type="text" name="emergency_contact" class="mmg-form-input" placeholder="Name & Phone number"
                               value="<?php echo clean($_POST['emergency_contact'] ?? ''); ?>">
                    </div>
                </div>
                
                <!-- Right Column - Membership & Account -->
                <div class="col-lg-6">
                    <h3 style="font-family:var(--font-heading);font-size:24px;color:var(--white);margin-bottom:24px;text-transform:uppercase;">Membership Details</h3>
                    
                    <div class="mmg-form-group">
                        <label class="mmg-form-label">Membership Plan *</label>
                        <select name="membership_plan" class="mmg-form-select" required id="planSelect">
                            <option value="">Select a Plan</option>
                            <?php foreach ($plans as $name => $plan): ?>
                            <option value="<?php echo $name; ?>" data-price="<?php echo $plan['price']; ?>" <?php echo $selectedPlan === $name ? 'selected' : ''; ?>>
                                <?php echo $name; ?> — ₦<?php echo number_format($plan['price']); ?> (<?php echo $plan['duration']; ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mmg-form-group" id="priceDisplay" style="display:<?php echo $selectedPlan ? 'block' : 'none'; ?>;">
                        <div style="background:var(--dark-card);padding:16px;border-radius:8px;border:1px solid var(--border-subtle);">
                            <span style="font-size:12px;color:var(--ash-gray);text-transform:uppercase;letter-spacing:0.08em;">Selected Price</span>
                            <div id="planPrice" style="font-family:var(--font-heading);font-size:32px;color:var(--coral-red);">
                                <?php echo $selectedPlan ? '₦' . number_format($plans[$selectedPlan]['price'] ?? 0) : ''; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mmg-form-group">
                        <label class="mmg-form-label">Passport Photo</label>
                        <div class="mmg-file-dropzone" onclick="document.getElementById('passportPhoto').click()">
                            <input type="file" name="passport_photo" id="passportPhoto" accept="image/jpeg,image/png">
                            <p class="mmg-file-dropzone-text"><span>Click to upload</span> or drag and drop<br><small style="color:var(--ash-gray);">JPG, PNG — Max 2MB</small></p>
                        </div>
                    </div>
                    
                    <div class="mmg-form-group">
                        <label class="mmg-form-label">Means of ID</label>
                        <div class="mmg-file-dropzone" onclick="document.getElementById('meansOfId').click()">
                            <input type="file" name="means_of_id" id="meansOfId" accept="image/jpeg,image/png">
                            <p class="mmg-file-dropzone-text"><span>Click to upload</span> or drag and drop<br><small style="color:var(--ash-gray);">National ID, Driver's License, Voter's Card — Max 2MB</small></p>
                        </div>
                    </div>
                    
                    <div class="mmg-form-group">
                        <label class="mmg-form-label">Medical Condition (Optional)</label>
                        <textarea name="medical_condition" class="mmg-form-textarea" placeholder="Please describe any medical conditions, allergies, or physical limitations we should be aware of"><?php echo clean($_POST['medical_condition'] ?? ''); ?></textarea>
                    </div>
                    
                    <h3 style="font-family:var(--font-heading);font-size:24px;color:var(--white);margin:32px 0 24px;text-transform:uppercase;">Account Setup</h3>
                    
                    <div class="mmg-form-group">
                        <label class="mmg-form-label">Username *</label>
                        <input type="text" name="username" class="mmg-form-input" placeholder="Choose a username" required minlength="3"
                               value="<?php echo clean($_POST['username'] ?? ''); ?>">
                    </div>
                    
                    <div class="mmg-form-group">
                        <label class="mmg-form-label">Password *</label>
                        <input type="password" name="password" class="mmg-form-input" placeholder="Min. 6 characters" required minlength="6">
                        <small style="color:var(--ash-gray);font-size:12px;margin-top:4px;display:block;">You'll use this to log in and check your application status.</small>
                    </div>
                    
                    <div class="mmg-form-group mt-4">
                        <button type="submit" class="mmg-btn mmg-btn-primary mmg-btn-full" style="padding:16px;">
                            SUBMIT APPLICATION
                        </button>
                    </div>
                </div>
            </div>
        </form>
        
        <script>
        // Price display update
        document.getElementById('planSelect').addEventListener('change', function() {
            const selected = this.options[this.selectedIndex];
            const price = selected.getAttribute('data-price');
            const display = document.getElementById('priceDisplay');
            const priceEl = document.getElementById('planPrice');
            if (price) {
                priceEl.textContent = '₦' + parseInt(price).toLocaleString();
                display.style.display = 'block';
            } else {
                display.style.display = 'none';
            }
        });
        </script>
        <?php endif; ?>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
