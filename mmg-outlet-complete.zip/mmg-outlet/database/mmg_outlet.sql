-- ============================================================
-- M.M.G OUTLET - Gym Membership Management System
-- Database Schema
-- Version: 1.0.0
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;
SET NAMES utf8mb4;

-- Drop tables if they exist (for clean install)
DROP TABLE IF EXISTS `id_cards`;
DROP TABLE IF EXISTS `payments`;
DROP TABLE IF EXISTS `memberships`;
DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `applicants`;
DROP TABLE IF EXISTS `settings`;
DROP TABLE IF EXISTS `admins`;

-- ============================================================
-- 1. ADMINS TABLE
-- ============================================================
CREATE TABLE `admins` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL DEFAULT 'Administrator',
  `email` VARCHAR(100) DEFAULT NULL,
  `role` ENUM('super_admin', 'admin') NOT NULL DEFAULT 'admin',
  `last_login` DATETIME DEFAULT NULL,
  `login_ip` VARCHAR(45) DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_username` (`username`),
  UNIQUE KEY `idx_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default admin (password: admin123 - hashed)
INSERT INTO `admins` (`username`, `password_hash`, `full_name`, `email`, `role`) VALUES
('admin', '$2y$10$f07f6axjgwCQEdaaHAvPSOH1M6wke97YEbKMlIRIrkSD7rAS4lpWm', 'System Administrator', 'admin@mmgoutlet.com', 'super_admin');

-- ============================================================
-- 2. APPLICANTS TABLE
-- ============================================================
CREATE TABLE `applicants` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(200) NOT NULL,
  `phone_number` VARCHAR(20) NOT NULL,
  `whatsapp_number` VARCHAR(20) DEFAULT NULL,
  `email` VARCHAR(100) DEFAULT NULL,
  `gender` ENUM('Male', 'Female', 'Other') NOT NULL,
  `date_of_birth` DATE DEFAULT NULL,
  `address` TEXT DEFAULT NULL,
  `state` VARCHAR(50) DEFAULT NULL,
  `occupation` VARCHAR(100) DEFAULT NULL,
  `emergency_contact` VARCHAR(200) DEFAULT NULL,
  `membership_plan` VARCHAR(50) NOT NULL,
  `plan_price` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `passport_photo` VARCHAR(255) DEFAULT NULL,
  `means_of_id` VARCHAR(255) DEFAULT NULL,
  `medical_condition` TEXT DEFAULT NULL,
  `username` VARCHAR(50) DEFAULT NULL,
  `password_hash` VARCHAR(255) DEFAULT NULL,
  `status` ENUM('Pending', 'Approved', 'Rejected', 'Suspended') NOT NULL DEFAULT 'Pending',
  `member_id` VARCHAR(20) DEFAULT NULL,
  `qr_code` VARCHAR(255) DEFAULT NULL,
  `applied_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `approved_at` DATETIME DEFAULT NULL,
  `approved_by` INT(11) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_username` (`username`),
  UNIQUE KEY `idx_member_id` (`member_id`),
  UNIQUE KEY `idx_email` (`email`),
  KEY `idx_status` (`status`),
  KEY `idx_plan` (`membership_plan`),
  KEY `idx_applied` (`applied_at`),
  CONSTRAINT `fk_approved_by` FOREIGN KEY (`approved_by`) REFERENCES `admins` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 3. MEMBERSHIPS TABLE
-- ============================================================
CREATE TABLE `memberships` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `applicant_id` INT(11) UNSIGNED NOT NULL,
  `member_id` VARCHAR(20) NOT NULL,
  `plan_name` VARCHAR(50) NOT NULL,
  `plan_price` DECIMAL(10,2) NOT NULL,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `duration_days` INT(11) NOT NULL DEFAULT 30,
  `status` ENUM('Active', 'Expired', 'Cancelled', 'Suspended') NOT NULL DEFAULT 'Active',
  `renewal_count` INT(11) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_member_id` (`member_id`),
  KEY `idx_applicant` (`applicant_id`),
  KEY `idx_status` (`status`),
  KEY `idx_end_date` (`end_date`),
  CONSTRAINT `fk_membership_applicant` FOREIGN KEY (`applicant_id`) REFERENCES `applicants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 4. ID_CARDS TABLE
-- ============================================================
CREATE TABLE `id_cards` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `applicant_id` INT(11) UNSIGNED NOT NULL,
  `member_id` VARCHAR(20) NOT NULL,
  `card_front` VARCHAR(255) DEFAULT NULL,
  `card_back` VARCHAR(255) DEFAULT NULL,
  `qr_code_data` VARCHAR(500) DEFAULT NULL,
  `print_count` INT(11) NOT NULL DEFAULT 0,
  `last_printed` DATETIME DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_member_id` (`member_id`),
  KEY `idx_applicant` (`applicant_id`),
  CONSTRAINT `fk_idcard_applicant` FOREIGN KEY (`applicant_id`) REFERENCES `applicants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 5. PAYMENTS TABLE
-- ============================================================
CREATE TABLE `payments` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `applicant_id` INT(11) UNSIGNED NOT NULL,
  `member_id` VARCHAR(20) DEFAULT NULL,
  `plan_name` VARCHAR(50) NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `payment_method` VARCHAR(50) DEFAULT 'Cash',
  `payment_status` ENUM('Pending', 'Paid', 'Failed', 'Refunded') NOT NULL DEFAULT 'Pending',
  `transaction_ref` VARCHAR(100) DEFAULT NULL,
  `paid_at` DATETIME DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_applicant` (`applicant_id`),
  KEY `idx_member` (`member_id`),
  KEY `idx_status` (`payment_status`),
  KEY `idx_paid_at` (`paid_at`),
  CONSTRAINT `fk_payment_applicant` FOREIGN KEY (`applicant_id`) REFERENCES `applicants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 6. SETTINGS TABLE
-- ============================================================
CREATE TABLE `settings` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `setting_key` VARCHAR(100) NOT NULL,
  `setting_value` TEXT DEFAULT NULL,
  `setting_group` VARCHAR(50) NOT NULL DEFAULT 'general',
  `is_public` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_key` (`setting_key`),
  KEY `idx_group` (`setting_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default settings
INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_group`, `is_public`) VALUES
('gym_name', 'M.M.G OUTLET', 'general', 1),
('gym_motto', 'Strength • Discipline • Fitness', 'general', 1),
('gym_address', '305B Tudun Yola Opposite AMK Petrol Station, Kano, Kano State, Nigeria', 'general', 1),
('gym_phone', '+234 912 717 1928', 'general', 1),
('gym_email', 'info@mmgoutlet.com', 'general', 1),
('gym_logo', 'assets/images/logo.png', 'general', 1),
('registration_form_price', '1000', 'pricing', 1),
('daily_gym_price', '3000', 'pricing', 1),
('one_month_price', '20000', 'pricing', 1),
('three_month_price', '60000', 'pricing', 1),
('whatsapp_link', 'https://wa.me/2349127171928', 'social', 1),
('instagram_link', 'https://instagram.com/mmgoutlet', 'social', 1),
('facebook_link', 'https://facebook.com/mmgoutlet', 'social', 1),
('twitter_link', 'https://twitter.com/mmgoutlet', 'social', 1),
('currency', '₦', 'general', 1),
('timezone', 'Africa/Lagos', 'general', 0),
('items_per_page', '20', 'general', 0),
('session_timeout', '1800', 'security', 0),
('max_upload_size', '2097152', 'security', 0),
('allowed_file_types', 'jpg,jpeg,png', 'security', 0);

-- ============================================================
-- 7. NOTIFICATIONS TABLE
-- ============================================================
CREATE TABLE `notifications` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `admin_id` INT(11) UNSIGNED DEFAULT NULL,
  `title` VARCHAR(200) NOT NULL,
  `message` TEXT NOT NULL,
  `type` ENUM('info', 'success', 'warning', 'error') NOT NULL DEFAULT 'info',
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `related_type` VARCHAR(50) DEFAULT NULL,
  `related_id` INT(11) UNSIGNED DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_admin` (`admin_id`),
  KEY `idx_read` (`is_read`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `fk_notification_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
