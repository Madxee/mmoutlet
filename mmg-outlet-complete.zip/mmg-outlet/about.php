<?php
/**
 * M.M.G OUTLET - About Page
 */

define('MMG_ACCESS', true);
$pageTitle = 'About Us';
require_once 'includes/header.php';
?>

<!-- Hero -->
<section class="mmg-about-hero">
    <div class="mmg-container text-center">
        <span class="mmg-section-label mmg-reveal">WHO WE ARE</span>
        <h1 class="mmg-about-hero-title mmg-reveal mmg-reveal-delay-1">ABOUT<br>M.M.G OUTLET</h1>
    </div>
</section>

<div class="mmg-separator"></div>

<!-- Our Story -->
<section class="mmg-section mmg-section-dark">
    <div class="mmg-container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <span class="mmg-section-label mmg-reveal">OUR STORY</span>
                <h2 class="mmg-section-title mmg-reveal mmg-reveal-delay-1">A VISION FOR<br>EXCELLENCE</h2>
                <p class="mmg-section-text mmg-reveal mmg-reveal-delay-2">
                    M.M.G OUTLET was founded with a singular mission: to create the most comprehensive, 
                    results-driven fitness environment in Kano. What started as a vision has evolved into 
                    a 25,000 square foot state-of-the-art facility that caters to everyone — from beginners 
                    taking their first steps into fitness to elite athletes pushing the boundaries of performance.
                </p>
                <p class="mmg-section-text mmg-reveal mmg-reveal-delay-2" style="margin-top: 16px;">
                    Our name stands for strength, discipline, and an unwavering commitment to helping every 
                    member achieve their personal best. We believe that fitness is not just about physical 
                    transformation — it's about building mental resilience, fostering discipline, and creating 
                    a lifestyle of continuous improvement.
                </p>
            </div>
            <div class="col-lg-6 mmg-reveal mmg-reveal-delay-3">
                <img src="assets/images/gym-about.jpg" alt="M.M.G OUTLET Facility" class="mmg-about-image">
            </div>
        </div>
    </div>
</section>

<!-- Features -->
<section class="mmg-section mmg-section-charcoal">
    <div class="mmg-container">
        <div class="text-center mb-5">
            <span class="mmg-section-label mmg-section-label-red mmg-reveal">WHY CHOOSE US</span>
            <h2 class="mmg-section-title mmg-reveal mmg-reveal-delay-1">WHAT SETS US<br>APART</h2>
        </div>
        <div class="row g-4">
            <div class="col-lg-6 mmg-reveal mmg-reveal-delay-1">
                <div class="mmg-feature-item">
                    <div class="mmg-feature-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>
                    </div>
                    <div>
                        <h3 class="mmg-feature-title">Expert Trainers</h3>
                        <p class="mmg-feature-desc">Our certified personal trainers bring years of experience and specialized knowledge in bodybuilding, CrossFit, nutrition, and rehabilitation.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 mmg-reveal mmg-reveal-delay-2">
                <div class="mmg-feature-item">
                    <div class="mmg-feature-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6.5 17H11"/><path d="M2 22V8.5L8.5 2H22V15.5L15.5 22H2Z"/><path d="M8.5 2V8.5H2"/><path d="M22 15.5H15.5V22"/></svg>
                    </div>
                    <div>
                        <h3 class="mmg-feature-title">Premium Equipment</h3>
                        <p class="mmg-feature-desc">We feature the latest strength training machines, free weights, cardio equipment, and functional training gear from top global brands.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 mmg-reveal mmg-reveal-delay-1">
                <div class="mmg-feature-item">
                    <div class="mmg-feature-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    </div>
                    <div>
                        <h3 class="mmg-feature-title">Community Atmosphere</h3>
                        <p class="mmg-feature-desc">Join a supportive community of like-minded individuals who motivate and inspire each other to reach new heights every day.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 mmg-reveal mmg-reveal-delay-2">
                <div class="mmg-feature-item">
                    <div class="mmg-feature-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                    </div>
                    <div>
                        <h3 class="mmg-feature-title">Flexible Hours</h3>
                        <p class="mmg-feature-desc">Open early morning to late evening, 7 days a week. Train on your schedule, not ours. Holiday hours available for committed members.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 mmg-reveal mmg-reveal-delay-3">
                <div class="mmg-feature-item">
                    <div class="mmg-feature-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>
                    </div>
                    <div>
                        <h3 class="mmg-feature-title">Spacious Facility</h3>
                        <p class="mmg-feature-desc">25,000 sq ft of intelligently designed training space. Never wait for equipment. Dedicated zones for every type of workout.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 mmg-reveal mmg-reveal-delay-3">
                <div class="mmg-feature-item">
                    <div class="mmg-feature-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                    </div>
                    <div>
                        <h3 class="mmg-feature-title">Safe & Secure</h3>
                        <p class="mmg-feature-desc">24/7 security, CCTV surveillance, secure locker rooms, and emergency protocols ensure your safety while you focus on your workout.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Motto Section -->
<section class="mmg-section mmg-section-dark" style="text-align:center;">
    <div class="mmg-container">
        <h2 class="mmg-section-title mmg-reveal" style="font-size:clamp(32px,5vw,56px);">
            STRENGTH <span style="color:var(--coral-red);">•</span> DISCIPLINE <span style="color:var(--coral-red);">•</span> FITNESS
        </h2>
        <p class="mmg-section-text mmg-reveal mmg-reveal-delay-1" style="margin:24px auto 0;">
            These three pillars define everything we do at M.M.G OUTLET. We believe that true fitness 
            comes from the combination of physical strength, mental discipline, and a holistic approach 
            to health and wellness.
        </p>
        <div class="mt-5 mmg-reveal mmg-reveal-delay-2">
            <a href="membership.php" class="mmg-btn mmg-btn-primary">View Membership Plans</a>
            <a href="apply.php" class="mmg-btn mmg-btn-outline ms-3">Apply Now</a>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
