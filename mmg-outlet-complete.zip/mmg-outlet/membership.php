<?php
/**
 * M.M.G OUTLET - Membership Plans Page
 */

define('MMG_ACCESS', true);
$pageTitle = 'Membership Plans';
require_once 'includes/header.php';

// Get pricing from settings
$plans = [
    'Registration Form' => [
        'price' => getSetting('registration_form_price', '1000'),
        'duration' => 'One-time',
        'desc' => 'Complete your registration to become a member of M.M.G OUTLET fitness community. Includes membership card processing.',
        'features' => ['Membership registration', 'ID card processing', 'Facility orientation', 'Access to member portal'],
        'popular' => false
    ],
    'Daily Gym' => [
        'price' => getSetting('daily_gym_price', '3000'),
        'duration' => '1 Day',
        'desc' => 'Full day access to all gym facilities, equipment, and training zones. Perfect for visitors and trial sessions.',
        'features' => ['Full facility access', 'All equipment usage', 'Locker room access', 'Shower facilities'],
        'popular' => false
    ],
    'One Month' => [
        'price' => getSetting('one_month_price', '20000'),
        'duration' => '30 Days',
        'desc' => 'Unlimited access for 30 days with complimentary fitness assessment and personalized workout plan.',
        'features' => ['Unlimited 30-day access', 'Free fitness assessment', 'Personalized workout plan', '1 PT session included', 'Locker assignment'],
        'popular' => true
    ],
    'Three Months' => [
        'price' => getSetting('three_month_price', '60000'),
        'duration' => '90 Days',
        'desc' => 'Best value package! Three months of unlimited access with bonus personal training sessions and nutrition guidance.',
        'features' => ['Unlimited 90-day access', '2 PT sessions included', 'Nutrition consultation', 'Body composition analysis', 'Priority class booking', 'Guest pass (2 visits)'],
        'popular' => false
    ],
];
?>

<section class="mmg-about-hero">
    <div class="mmg-container text-center">
        <span class="mmg-section-label mmg-reveal">CHOOSE YOUR PLAN</span>
        <h1 class="mmg-about-hero-title mmg-reveal mmg-reveal-delay-1">MEMBERSHIP<br>PLANS</h1>
        <p class="mmg-section-text mmg-reveal mmg-reveal-delay-2" style="margin:20px auto 0;max-width:500px;">
            Select the plan that fits your goals and lifestyle. All plans include full access to our premium facilities.
        </p>
    </div>
</section>

<div class="mmg-separator"></div>

<section class="mmg-section mmg-section-dark">
    <div class="mmg-container">
        <div class="row g-4 justify-content-center">
            <?php $delay = 1; foreach ($plans as $name => $plan): ?>
            <div class="col-lg-3 col-md-6 mmg-reveal mmg-reveal-delay-<?php echo $delay; ?>">
                <div class="mmg-pricing-card <?php echo $plan['popular'] ? 'mmg-plan-highlight' : ''; ?>" style="height:100%;display:flex;flex-direction:column;">
                    <div style="flex:1;">
                        <h3 class="mmg-pricing-name"><?php echo clean($name); ?></h3>
                        <div class="mmg-pricing-price" data-price-default="₦<?php echo number_format($plan['price']); ?>" data-price-hover="₦<?php echo number_format($plan['price']); ?>" data-scramble-chars="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ">₦<?php echo number_format($plan['price']); ?></div>
                        <span class="mmg-pricing-duration"><?php echo clean($plan['duration']); ?></span>
                        <p class="mmg-pricing-desc"><?php echo clean($plan['desc']); ?></p>
                        <ul style="list-style:none;padding:0;margin:0 0 24px 0;">
                            <?php foreach ($plan['features'] as $feature): ?>
                            <li style="font-size:14px;color:var(--ice-gray);padding:6px 0;border-bottom:1px solid var(--border-subtle);display:flex;align-items:center;gap:8px;">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#2E7D6F" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                                <?php echo clean($feature); ?>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <a href="apply.php?plan=<?php echo urlencode($name); ?>" class="mmg-btn mmg-btn-primary mmg-btn-full" style="margin-top:auto;">SELECT PLAN</a>
                </div>
            </div>
            <?php $delay = $delay >= 4 ? 1 : $delay + 1; endforeach; ?>
        </div>
    </div>
</section>

<!-- Comparison Section -->
<section class="mmg-section mmg-section-charcoal">
    <div class="mmg-container">
        <div class="text-center mb-5">
            <span class="mmg-section-label mmg-section-label-red mmg-reveal">COMPARE</span>
            <h2 class="mmg-section-title mmg-reveal mmg-reveal-delay-1">PLAN<br>COMPARISON</h2>
        </div>
        <div class="table-responsive mmg-reveal mmg-reveal-delay-2">
            <table style="width:100%;border-collapse:collapse;font-family:var(--font-body);font-size:14px;">
                <thead>
                    <tr style="border-bottom:2px solid var(--coral-red);">
                        <th style="padding:16px;text-align:left;color:var(--white);font-weight:600;text-transform:uppercase;font-size:12px;letter-spacing:0.08em;">Features</th>
                        <th style="padding:16px;text-align:center;color:var(--white);font-weight:600;text-transform:uppercase;font-size:12px;letter-spacing:0.08em;">Registration</th>
                        <th style="padding:16px;text-align:center;color:var(--white);font-weight:600;text-transform:uppercase;font-size:12px;letter-spacing:0.08em;">Daily</th>
                        <th style="padding:16px;text-align:center;color:var(--gold-accent);font-weight:600;text-transform:uppercase;font-size:12px;letter-spacing:0.08em;">1 Month ★</th>
                        <th style="padding:16px;text-align:center;color:var(--white);font-weight:600;text-transform:uppercase;font-size:12px;letter-spacing:0.08em;">3 Months</th>
                    </tr>
                </thead>
                <tbody>
                    <tr style="border-bottom:1px solid var(--border-subtle);">
                        <td style="padding:14px 16px;color:var(--ice-gray);">Facility Access</td>
                        <td style="padding:14px 16px;text-align:center;color:#2E7D6F;">✓</td>
                        <td style="padding:14px 16px;text-align:center;color:#2E7D6F;">✓</td>
                        <td style="padding:14px 16px;text-align:center;color:#2E7D6F;">✓</td>
                        <td style="padding:14px 16px;text-align:center;color:#2E7D6F;">✓</td>
                    </tr>
                    <tr style="border-bottom:1px solid var(--border-subtle);background:var(--dark-card);">
                        <td style="padding:14px 16px;color:var(--ice-gray);">All Equipment</td>
                        <td style="padding:14px 16px;text-align:center;color:#2E7D6F;">✓</td>
                        <td style="padding:14px 16px;text-align:center;color:#2E7D6F;">✓</td>
                        <td style="padding:14px 16px;text-align:center;color:#2E7D6F;">✓</td>
                        <td style="padding:14px 16px;text-align:center;color:#2E7D6F;">✓</td>
                    </tr>
                    <tr style="border-bottom:1px solid var(--border-subtle);">
                        <td style="padding:14px 16px;color:var(--ice-gray);">Locker Room</td>
                        <td style="padding:14px 16px;text-align:center;color:#595959;">—</td>
                        <td style="padding:14px 16px;text-align:center;color:#2E7D6F;">✓</td>
                        <td style="padding:14px 16px;text-align:center;color:#2E7D6F;">✓</td>
                        <td style="padding:14px 16px;text-align:center;color:#2E7D6F;">✓</td>
                    </tr>
                    <tr style="border-bottom:1px solid var(--border-subtle);background:var(--dark-card);">
                        <td style="padding:14px 16px;color:var(--ice-gray);">Fitness Assessment</td>
                        <td style="padding:14px 16px;text-align:center;color:#595959;">—</td>
                        <td style="padding:14px 16px;text-align:center;color:#595959;">—</td>
                        <td style="padding:14px 16px;text-align:center;color:#2E7D6F;">✓</td>
                        <td style="padding:14px 16px;text-align:center;color:#2E7D6F;">✓</td>
                    </tr>
                    <tr style="border-bottom:1px solid var(--border-subtle);">
                        <td style="padding:14px 16px;color:var(--ice-gray);">Personal Training</td>
                        <td style="padding:14px 16px;text-align:center;color:#595959;">—</td>
                        <td style="padding:14px 16px;text-align:center;color:#595959;">—</td>
                        <td style="padding:14px 16px;text-align:center;color:#2E7D6F;">1 Session</td>
                        <td style="padding:14px 16px;text-align:center;color:#2E7D6F;">2 Sessions</td>
                    </tr>
                    <tr style="border-bottom:1px solid var(--border-subtle);background:var(--dark-card);">
                        <td style="padding:14px 16px;color:var(--ice-gray);">Nutrition Guide</td>
                        <td style="padding:14px 16px;text-align:center;color:#595959;">—</td>
                        <td style="padding:14px 16px;text-align:center;color:#595959;">—</td>
                        <td style="padding:14px 16px;text-align:center;color:#595959;">—</td>
                        <td style="padding:14px 16px;text-align:center;color:#2E7D6F;">✓</td>
                    </tr>
                    <tr style="border-bottom:1px solid var(--border-subtle);">
                        <td style="padding:14px 16px;color:var(--ice-gray);">Guest Passes</td>
                        <td style="padding:14px 16px;text-align:center;color:#595959;">—</td>
                        <td style="padding:14px 16px;text-align:center;color:#595959;">—</td>
                        <td style="padding:14px 16px;text-align:center;color:#595959;">—</td>
                        <td style="padding:14px 16px;text-align:center;color:#2E7D6F;">2 Visits</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
