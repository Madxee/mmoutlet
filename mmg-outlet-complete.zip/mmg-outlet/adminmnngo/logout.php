<?php
/**
 * M.M.G OUTLET - Admin Logout
 */

require_once '../includes/functions.php';

adminLogout();
redirect('index.php', 'You have been logged out successfully.', 'success');
