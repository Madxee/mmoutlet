<?php
/**
 * M.M.G OUTLET - Public Member Verification
 * Verifies a member via QR code scan
 */

require_once '../includes/functions.php';

$memberId = trim($_GET['mid'] ?? '');
$verified = false;
$member = null;
$membership = null;

if ($memberId) {
    $member = dbFetch("SELECT * FROM applicants WHERE member_id = ? AND status = 'Approved' LIMIT 1", [$memberId]);
    if ($member) {
        $membership = dbFetch("SELECT * FROM memberships WHERE applicant_id = ? AND status = 'Active' LIMIT 1", [$member['id']]);
        $verified = $membership && $membership['end_date'] >= date('Y-m-d');
    }
}

$gymName = getSetting('gym_name', 'M.M.G OUTLET');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Verification | <?php echo clean($gymName); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Manrope:wght@300;400;500;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --void-black: #050505;
            --charcoal: #111111;
            --coral-red: #FF5252;
            --jade-green: #2E7D6F;
            --gold-accent: #D4A843;
            --white: #FFFFFF;
            --ice-gray: #C0C0C0;
            --ash-gray: #595959;
            --font-heading: 'Instrument Serif', serif;
            --font-body: 'Manrope', sans-serif;
            --font-mono: 'Space Mono', monospace;
        }
        * { margin:0;padding:0;box-sizing:border-box; }
        body {
            font-family: var(--font-body);
            background: var(--void-black);
            color: var(--white);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }
        .verify-container {
            max-width: 420px;
            width: 100%;
            text-align: center;
        }
        .verify-logo {
            margin-bottom: 32px;
        }
        .verify-logo img {
            height: 80px;
            width: auto;
        }
        .verify-card {
            background: var(--charcoal);
            border: 1px solid rgba(255,255,255,0.06);
            border-radius: 12px;
            padding: 40px 32px;
            position: relative;
            overflow: hidden;
        }
        .verify-status {
            width: 72px;
            height: 72px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 32px;
        }
        .verify-status.verified {
            background: rgba(46,125,111,0.15);
            color: var(--jade-green);
            border: 2px solid var(--jade-green);
        }
        .verify-status.invalid {
            background: rgba(211,47,47,0.15);
            color: var(--coral-red);
            border: 2px solid var(--coral-red);
        }
        .verify-title {
            font-family: var(--font-heading);
            font-size: 28px;
            margin-bottom: 8px;
        }
        .verify-title.verified { color: var(--jade-green); }
        .verify-title.invalid { color: var(--coral-red); }
        .verify-member-name {
            font-family: var(--font-heading);
            font-size: 22px;
            color: var(--white);
            margin-bottom: 4px;
        }
        .verify-member-id {
            font-family: var(--font-mono);
            font-size: 16px;
            color: var(--gold-accent);
            margin-bottom: 20px;
            letter-spacing: 2px;
        }
        .verify-detail {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid rgba(255,255,255,0.06);
            font-size: 14px;
        }
        .verify-detail-label { color: var(--ash-gray); }
        .verify-detail-value { color: var(--white); font-weight: 500; }
        .verify-expiry {
            margin-top: 20px;
            padding: 12px;
            border-radius: 6px;
            font-size: 13px;
        }
        .verify-expiry.valid {
            background: rgba(46,125,111,0.1);
            color: var(--jade-green);
        }
        .verify-expiry.expired {
            background: rgba(211,47,47,0.1);
            color: var(--coral-red);
        }
        .verify-footer {
            margin-top: 24px;
            font-size: 12px;
            color: var(--ash-gray);
        }
        .verify-scan-form {
            margin-top: 24px;
        }
        .verify-scan-form input {
            width: 100%;
            padding: 14px 16px;
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 8px;
            color: var(--white);
            font-family: var(--font-body);
            font-size: 15px;
            outline: none;
            margin-bottom: 12px;
            text-align: center;
            letter-spacing: 2px;
            font-family: var(--font-mono);
        }
        .verify-scan-form input:focus {
            border-color: var(--gold-accent);
        }
        .verify-scan-form button {
            width: 100%;
            padding: 14px;
            background: var(--coral-red);
            color: var(--white);
            border: none;
            font-family: var(--font-body);
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            cursor: pointer;
            border-radius: 8px;
            transition: background 0.2s ease;
        }
        .verify-scan-form button:hover {
            background: var(--signal-red);
        }
        .powered-by {
            margin-top: 24px;
            font-size: 11px;
            color: var(--ash-gray);
            text-transform: uppercase;
            letter-spacing: 0.1em;
        }
    </style>
</head>
<body>
    <div class="verify-container">
        <div class="verify-logo">
            <img src="../assets/images/logo.png" alt="<?php echo clean($gymName); ?>">
        </div>
        
        <?php if ($member): ?>
        <div class="verify-card">
            <?php if ($verified): ?>
            <div class="verify-status verified">✓</div>
            <h1 class="verify-title verified">VERIFIED</h1>
            <p style="color:var(--ice-gray);font-size:14px;margin-bottom:24px;">Valid M.M.G OUTLET Member</p>
            <?php else: ?>
            <div class="verify-status invalid">✕</div>
            <h1 class="verify-title invalid">EXPIRED</h1>
            <p style="color:var(--ice-gray);font-size:14px;margin-bottom:24px;">Membership has expired</p>
            <?php endif; ?>
            
            <div class="verify-member-name"><?php echo clean(strtoupper($member['full_name'])); ?></div>
            <div class="verify-member-id"><?php echo $member['member_id']; ?></div>
            
            <div style="text-align:left;margin-top:16px;">
                <div class="verify-detail">
                    <span class="verify-detail-label">Plan</span>
                    <span class="verify-detail-value"><?php echo clean($member['membership_plan']); ?></span>
                </div>
                <div class="verify-detail">
                    <span class="verify-detail-label">Phone</span>
                    <span class="verify-detail-value"><?php echo clean($member['phone_number']); ?></span>
                </div>
                <?php if ($membership): ?>
                <div class="verify-detail">
                    <span class="verify-detail-label">Start Date</span>
                    <span class="verify-detail-value"><?php echo formatDate($membership['start_date']); ?></span>
                </div>
                <div class="verify-detail">
                    <span class="verify-detail-label">Expiry Date</span>
                    <span class="verify-detail-value" style="color:<?php echo $verified ? 'var(--jade-green)' : 'var(--coral-red)'; ?>;"><?php echo formatDate($membership['end_date']); ?></span>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="verify-expiry <?php echo $verified ? 'valid' : 'expired'; ?>">
                <?php echo $verified ? '✓ Membership is active and valid' : '✕ Membership expired — Please renew'; ?>
            </div>
        </div>
        
        <?php else: ?>
        <div class="verify-card">
            <div class="verify-status invalid">?</div>
            <h1 class="verify-title invalid">NOT FOUND</h1>
            <p style="color:var(--ice-gray);font-size:14px;margin-bottom:24px;">Invalid or missing member ID</p>
            
            <form class="verify-scan-form" method="GET">
                <input type="text" name="mid" placeholder="ENTER MEMBER ID" value="<?php echo clean($memberId); ?>" autofocus>
                <button type="submit">VERIFY</button>
            </form>
        </div>
        <?php endif; ?>
        
        <div class="verify-footer">
            <p><?php echo clean($gymName); ?> — <?php echo clean(getSetting('gym_address', 'Kano, Nigeria')); ?></p>
            <p class="powered-by">Member Verification System</p>
        </div>
    </div>
</body>
</html>
