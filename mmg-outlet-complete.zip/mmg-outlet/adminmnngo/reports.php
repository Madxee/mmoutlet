<?php
/**
 * M.M.G OUTLET - Reports System
 * Generate daily, monthly, and member reports with export
 */

require_once 'includes/header.php';

// Get filter
$reportType = $_GET['type'] ?? 'daily';
$reportDate = $_GET['date'] ?? date('Y-m-d');
$reportMonth = $_GET['month'] ?? date('Y-m');

// Daily registrations
$dailyRegs = dbFetchAll(
    "SELECT * FROM applicants WHERE DATE(applied_at) = ? ORDER BY applied_at DESC",
    [$reportDate]
);
$dailyTotal = dbFetch("SELECT COALESCE(SUM(plan_price), 0) as total, COUNT(*) as count FROM applicants WHERE DATE(applied_at) = ?", [$reportDate]);

// Monthly income
list($year, $month) = explode('-', $reportMonth);
$monthlyRegs = dbFetchAll(
    "SELECT * FROM applicants WHERE MONTH(applied_at) = ? AND YEAR(applied_at) = ? ORDER BY applied_at DESC",
    [$month, $year]
);
$monthlyTotal = dbFetch("SELECT COALESCE(SUM(plan_price), 0) as total, COUNT(*) as count FROM applicants WHERE MONTH(applied_at) = ? AND YEAR(applied_at) = ? AND status = 'Approved'", [$month, $year]);

// Monthly breakdown by plan
$planBreakdown = dbFetchAll(
    "SELECT membership_plan, COUNT(*) as count, COALESCE(SUM(plan_price), 0) as revenue 
     FROM applicants WHERE MONTH(applied_at) = ? AND YEAR(applied_at) = ? AND status = 'Approved'
     GROUP BY membership_plan",
    [$month, $year]
);

// Active/Expired members
$activeMembers = dbFetchAll(
    "SELECT a.*, m.end_date FROM applicants a 
     JOIN memberships m ON a.id = m.applicant_id 
     WHERE a.status = 'Approved' AND m.status = 'Active' AND m.end_date >= CURDATE()
     ORDER BY m.end_date ASC LIMIT 100"
);
$expiredMembers = dbFetchAll(
    "SELECT a.*, m.end_date FROM applicants a 
     JOIN memberships m ON a.id = m.applicant_id 
     WHERE a.status = 'Approved' AND (m.status = 'Expired' OR m.end_date < CURDATE())
     ORDER BY m.end_date DESC LIMIT 100"
);

// Handle CSV Export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="mmg_report_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    fputcsv($output, ['M.M.G OUTLET - Report']);
    fputcsv($output, ['Generated: ' . date('Y-m-d H:i:s')]);
    fputcsv($output, []);
    fputcsv($output, ['ID', 'Full Name', 'Phone', 'Email', 'Plan', 'Price', 'Status', 'Date']);
    
    $dataToExport = $reportType === 'daily' ? $dailyRegs : $monthlyRegs;
    foreach ($dataToExport as $row) {
        fputcsv($output, [
            $row['id'], $row['full_name'], $row['phone_number'], $row['email'],
            $row['membership_plan'], $row['plan_price'], $row['status'], $row['applied_at']
        ]);
    }
    fclose($output);
    exit;
}

// Months for dropdown
$months = [];
for ($i = 0; $i < 12; $i++) {
    $ts = strtotime("-{$i} months");
    $months[date('Y-m', $ts)] = date('F Y', $ts);
}
?>

<!-- Report Tabs -->
<div class="row g-4 mb-4">
    <div class="col-12">
        <div class="admin-table-wrapper" style="padding:24px;">
            <div class="d-flex gap-2 mb-4 flex-wrap">
                <a href="?type=daily" class="admin-btn <?php echo $reportType === 'daily' ? 'admin-btn-primary' : 'admin-btn-secondary'; ?> admin-btn-sm">Daily Registrations</a>
                <a href="?type=monthly" class="admin-btn <?php echo $reportType === 'monthly' ? 'admin-btn-primary' : 'admin-btn-secondary'; ?> admin-btn-sm">Monthly Income</a>
                <a href="?type=members" class="admin-btn <?php echo $reportType === 'members' ? 'admin-btn-primary' : 'admin-btn-secondary'; ?> admin-btn-sm">Active/Expired</a>
            </div>
            
            <?php if ($reportType === 'daily'): ?>
            <!-- Daily Report -->
            <form method="GET" class="row g-3 align-items-end mb-4">
                <input type="hidden" name="type" value="daily">
                <div class="col-auto">
                    <label class="admin-form-label">Select Date</label>
                    <input type="date" name="date" class="admin-form-input" value="<?php echo $reportDate; ?>" onchange="this.form.submit()" style="width:auto;">
                </div>
                <div class="col-auto">
                    <a href="?type=daily&export=csv&date=<?php echo $reportDate; ?>" class="admin-btn admin-btn-secondary admin-btn-sm">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                        Export CSV
                    </a>
                </div>
            </form>
            
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="admin-stat-card">
                        <div class="admin-stat-value" style="font-size:28px;"><?php echo number_format($dailyTotal['count'] ?? 0); ?></div>
                        <div class="admin-stat-label">Registrations</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="admin-stat-card">
                        <div class="admin-stat-value" style="font-size:28px;color:var(--gold-accent);">₦<?php echo number_format($dailyTotal['total'] ?? 0); ?></div>
                        <div class="admin-stat-label">Total Revenue</div>
                    </div>
                </div>
            </div>
            
            <div class="table-responsive">
                <table class="admin-table">
                    <thead>
                        <tr><th>ID</th><th>Name</th><th>Plan</th><th>Price</th><th>Status</th><th>Time</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dailyRegs as $row): ?>
                        <tr>
                            <td class="cell-mono">#<?php echo $row['id']; ?></td>
                            <td class="cell-name"><?php echo clean($row['full_name']); ?></td>
                            <td><?php echo clean($row['membership_plan']); ?></td>
                            <td style="color:var(--coral-red);">₦<?php echo number_format($row['plan_price']); ?></td>
                            <td><?php echo statusBadge($row['status']); ?></td>
                            <td><?php echo date('h:i A', strtotime($row['applied_at'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($dailyRegs)): ?>
                        <tr><td colspan="6" style="text-align:center;padding:32px;color:var(--ash-gray);">No registrations on this date.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php elseif ($reportType === 'monthly'): ?>
            <!-- Monthly Report -->
            <form method="GET" class="row g-3 align-items-end mb-4">
                <input type="hidden" name="type" value="monthly">
                <div class="col-auto">
                    <label class="admin-form-label">Select Month</label>
                    <select name="month" class="admin-form-select" onchange="this.form.submit()" style="width:auto;min-width:160px;">
                        <?php foreach ($months as $val => $label): ?>
                        <option value="<?php echo $val; ?>" <?php echo $reportMonth === $val ? 'selected' : ''; ?>><?php echo $label; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-auto">
                    <a href="?type=monthly&export=csv&month=<?php echo $reportMonth; ?>" class="admin-btn admin-btn-secondary admin-btn-sm">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                        Export CSV
                    </a>
                </div>
            </form>
            
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="admin-stat-card">
                        <div class="admin-stat-value" style="font-size:28px;"><?php echo number_format($monthlyTotal['count'] ?? 0); ?></div>
                        <div class="admin-stat-label">Approved Members</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="admin-stat-card">
                        <div class="admin-stat-value" style="font-size:28px;color:var(--gold-accent);">₦<?php echo number_format($monthlyTotal['total'] ?? 0); ?></div>
                        <div class="admin-stat-label">Total Revenue</div>
                    </div>
                </div>
            </div>
            
            <!-- Plan Breakdown Chart -->
            <div style="max-width:500px;margin-bottom:32px;">
                <canvas id="planChart" height="200"></canvas>
            </div>
            
            <div class="table-responsive">
                <table class="admin-table">
                    <thead>
                        <tr><th>Plan</th><th>Members</th><th>Revenue</th><th>% of Total</th></tr>
                    </thead>
                    <tbody>
                        <?php 
                        $grandTotal = $monthlyTotal['total'] ?? 0;
                        foreach ($planBreakdown as $pb): 
                        ?>
                        <tr>
                            <td class="cell-name"><?php echo clean($pb['membership_plan']); ?></td>
                            <td><?php echo number_format($pb['count']); ?></td>
                            <td style="color:var(--coral-red);">₦<?php echo number_format($pb['revenue']); ?></td>
                            <td><?php echo $grandTotal > 0 ? round(($pb['revenue'] / $grandTotal) * 100, 1) : 0; ?>%</td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <script>
            new Chart(document.getElementById('planChart').getContext('2d'), {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode(array_column($planBreakdown, 'membership_plan')); ?>,
                    datasets: [{
                        label: 'Revenue (₦)',
                        data: <?php echo json_encode(array_map('floatval', array_column($planBreakdown, 'revenue'))); ?>,
                        backgroundColor: ['#FF5252', '#D4A843', '#2E7D6F', '#595959'],
                        borderRadius: 4,
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    plugins: { legend: { display: false } },
                    scales: {
                        x: { grid: { display: false }, ticks: { color: '#C0C0C0', font: { family: 'Manrope', size: 11 } } },
                        y: { grid: { color: 'rgba(255,255,255,0.03)' }, ticks: { color: '#595959', font: { family: 'Manrope', size: 11 }, callback: function(v) { return '₦' + v.toLocaleString(); } } }
                    }
                }
            });
            </script>
            
            <?php else: ?>
            <!-- Active/Expired Members -->
            <div class="row g-4">
                <div class="col-lg-6">
                    <h4 style="font-family:var(--font-heading);font-size:18px;color:var(--jade-green);margin-bottom:16px;">Active Members (<?php echo count($activeMembers); ?>)</h4>
                    <div class="table-responsive">
                        <table class="admin-table">
                            <thead>
                                <tr><th>Name</th><th>Plan</th><th>Expires</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($activeMembers as $am): ?>
                                <tr>
                                    <td class="cell-name" style="font-size:13px;"><?php echo clean($am['full_name']); ?></td>
                                    <td style="font-size:13px;"><?php echo clean($am['membership_plan']); ?></td>
                                    <td style="font-size:12px;color:var(--ice-gray);"><?php echo formatDate($am['end_date']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if (empty($activeMembers)): ?>
                                <tr><td colspan="3" style="text-align:center;padding:24px;color:var(--ash-gray);">No active members.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-lg-6">
                    <h4 style="font-family:var(--font-heading);font-size:18px;color:var(--signal-red);margin-bottom:16px;">Expired Memberships (<?php echo count($expiredMembers); ?>)</h4>
                    <div class="table-responsive">
                        <table class="admin-table">
                            <thead>
                                <tr><th>Name</th><th>Plan</th><th>Expired</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($expiredMembers as $em): ?>
                                <tr>
                                    <td class="cell-name" style="font-size:13px;"><?php echo clean($em['full_name']); ?></td>
                                    <td style="font-size:13px;"><?php echo clean($em['membership_plan']); ?></td>
                                    <td style="font-size:12px;color:var(--coral-red);"><?php echo formatDate($em['end_date']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if (empty($expiredMembers)): ?>
                                <tr><td colspan="3" style="text-align:center;padding:24px;color:var(--ash-gray);">No expired memberships.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
