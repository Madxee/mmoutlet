<?php
/**
 * M.M.G OUTLET - Member Verification Page
 * View applicant details, verify, and generate QR code
 */

require_once 'includes/header.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) {
    redirect('applicants.php');
}

$applicant = getApplicant($id);
if (!$applicant) {
    redirect('applicants.php?error=not_found');
}

// Get membership info
$membership = dbFetch("SELECT * FROM memberships WHERE applicant_id = ? LIMIT 1", [$id]);

// Get ID card info
$idCard = dbFetch("SELECT * FROM id_cards WHERE applicant_id = ? LIMIT 1", [$id]);

// Generate QR code data URL
$qrData = '';
if ($applicant['member_id']) {
    $verifyUrl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/verify-member.php?mid=' . urlencode($applicant['member_id']);
    $qrData = $verifyUrl;
}

$gymAddress = getSetting('gym_address', '305B Tudun Yola, Kano');
$gymPhone = getSetting('gym_phone', '+234 912 717 1928');
?>

<!-- Applicant Details -->
<div class="row g-4">
    <!-- Left: Profile -->
    <div class="col-lg-4">
        <div class="admin-table-wrapper" style="padding:24px;text-align:center;">
            <?php if ($applicant['passport_photo']): ?>
            <img src="../<?php echo $applicant['passport_photo']; ?>" alt="" style="width:140px;height:140px;border-radius:50%;object-fit:cover;border:3px solid var(--gold-accent);margin-bottom:16px;">
            <?php else: ?>
            <div style="width:140px;height:140px;border-radius:50%;background:linear-gradient(135deg,var(--coral-red),var(--signal-red));display:flex;align-items:center;justify-content:center;font-size:48px;font-weight:700;color:#fff;margin:0 auto 16px;">
                <?php echo strtoupper(substr($applicant['full_name'], 0, 1)); ?>
            </div>
            <?php endif; ?>
            
            <h3 style="font-family:var(--font-heading);font-size:22px;color:var(--white);margin-bottom:4px;"><?php echo clean($applicant['full_name']); ?></h3>
            <p style="font-size:13px;color:var(--ash-gray);margin-bottom:12px;">Applied: <?php echo formatDate($applicant['applied_at']); ?></p>
            
            <?php echo statusBadge($applicant['status']); ?>
            
            <?php if ($applicant['member_id']): ?>
            <div style="margin-top:16px;padding:12px;background:rgba(212,168,67,0.08);border-radius:6px;">
                <div style="font-size:11px;color:var(--ash-gray);text-transform:uppercase;letter-spacing:0.08em;">Member ID</div>
                <div style="font-family:var(--font-mono);font-size:18px;color:var(--gold-accent);font-weight:700;"><?php echo $applicant['member_id']; ?></div>
            </div>
            <?php endif; ?>
            
            <div class="mt-3 d-flex flex-column gap-2">
                <?php if ($applicant['status'] === 'Pending'): ?>
                <form method="POST" action="applicants.php" onsubmit="return confirm('Approve this applicant and generate Member ID?')" style="display:inline;">
                    <?php echo csrfField(); ?>
                    <input type="hidden" name="action" value="approve">
                    <input type="hidden" name="applicant_id" value="<?php echo $applicant['id']; ?>">
                    <button type="submit" class="admin-btn admin-btn-success" style="width:100%;">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                        Approve Member
                    </button>
                </form>
                <form method="POST" action="applicants.php" onsubmit="return confirm('Reject this applicant?')" style="display:inline;">
                    <?php echo csrfField(); ?>
                    <input type="hidden" name="action" value="reject">
                    <input type="hidden" name="applicant_id" value="<?php echo $applicant['id']; ?>">
                    <button type="submit" class="admin-btn admin-btn-danger" style="width:100%;">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                        Reject Application
                    </button>
                </form>
                <?php endif; ?>
                
                <?php if ($applicant['status'] === 'Approved' && $applicant['member_id']): ?>
                <a href="print-id.php?id=<?php echo $applicant['id']; ?>" class="admin-btn admin-btn-gold" style="width:100%;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                    Print ID Card
                </a>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- QR Code -->
        <?php if ($qrData): ?>
        <div class="admin-table-wrapper mt-4" style="padding:24px;text-align:center;">
            <h4 style="font-family:var(--font-heading);font-size:16px;color:var(--white);margin-bottom:16px;">Verification QR Code</h4>
            <div id="qrcode" style="display:inline-block;padding:12px;background:#fff;border-radius:8px;"></div>
            <p style="font-size:12px;color:var(--ash-gray);margin-top:12px;">Scan to verify membership</p>
            <p class="cell-mono" style="font-size:11px;color:var(--gold-accent);margin-top:4px;"><?php echo $applicant['member_id']; ?></p>
        </div>
        <script>
        new QRCode(document.getElementById('qrcode'), {
            text: <?php echo json_encode($qrData); ?>,
            width: 150,
            height: 150,
            colorDark: '#000000',
            colorLight: '#ffffff',
            correctLevel: QRCode.CorrectLevel.M
        });
        </script>
        <?php endif; ?>
    </div>
    
    <!-- Right: Details -->
    <div class="col-lg-8">
        <div class="admin-table-wrapper">
            <div style="padding:20px 24px;border-bottom:1px solid var(--border-subtle);">
                <h3 style="font-family:var(--font-heading);font-size:20px;color:var(white);margin:0;">Personal Information</h3>
            </div>
            <div style="padding:24px;">
                <div class="row g-4">
                    <div class="col-md-6">
                        <div style="margin-bottom:20px;">
                            <div class="admin-form-label">Full Name</div>
                            <div style="color:var(--white);font-size:15px;"><?php echo clean($applicant['full_name']); ?></div>
                        </div>
                        <div style="margin-bottom:20px;">
                            <div class="admin-form-label">Phone Number</div>
                            <div style="color:var(--white);font-size:15px;"><?php echo clean($applicant['phone_number']); ?></div>
                        </div>
                        <div style="margin-bottom:20px;">
                            <div class="admin-form-label">WhatsApp</div>
                            <div style="color:var(--white);font-size:15px;"><?php echo clean($applicant['whatsapp_number'] ?: 'N/A'); ?></div>
                        </div>
                        <div style="margin-bottom:20px;">
                            <div class="admin-form-label">Email</div>
                            <div style="color:var(--white);font-size:15px;"><?php echo clean($applicant['email'] ?: 'N/A'); ?></div>
                        </div>
                        <div style="margin-bottom:20px;">
                            <div class="admin-form-label">Gender</div>
                            <div style="color:var(--white);font-size:15px;"><?php echo clean($applicant['gender'] ?: 'N/A'); ?></div>
                        </div>
                        <div style="margin-bottom:20px;">
                            <div class="admin-form-label">Date of Birth</div>
                            <div style="color:var(--white);font-size:15px;"><?php echo $applicant['date_of_birth'] ? formatDate($applicant['date_of_birth']) : 'N/A'; ?></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div style="margin-bottom:20px;">
                            <div class="admin-form-label">Address</div>
                            <div style="color:var(--white);font-size:15px;"><?php echo clean($applicant['address'] ?: 'N/A'); ?></div>
                        </div>
                        <div style="margin-bottom:20px;">
                            <div class="admin-form-label">State</div>
                            <div style="color:var(--white);font-size:15px;"><?php echo clean($applicant['state'] ?: 'N/A'); ?></div>
                        </div>
                        <div style="margin-bottom:20px;">
                            <div class="admin-form-label">Occupation</div>
                            <div style="color:var(--white);font-size:15px;"><?php echo clean($applicant['occupation'] ?: 'N/A'); ?></div>
                        </div>
                        <div style="margin-bottom:20px;">
                            <div class="admin-form-label">Emergency Contact</div>
                            <div style="color:var(--white);font-size:15px;"><?php echo clean($applicant['emergency_contact'] ?: 'N/A'); ?></div>
                        </div>
                        <div style="margin-bottom:20px;">
                            <div class="admin-form-label">Medical Condition</div>
                            <div style="color:var(--white);font-size:15px;"><?php echo clean($applicant['medical_condition'] ?: 'None'); ?></div>
                        </div>
                        <div style="margin-bottom:20px;">
                            <div class="admin-form-label">Username</div>
                            <div style="color:var(--white);font-size:15px;font-family:var(--font-mono);"><?php echo clean($applicant['username'] ?: 'N/A'); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Membership Info -->
        <div class="admin-table-wrapper mt-4">
            <div style="padding:20px 24px;border-bottom:1px solid var(--border-subtle);">
                <h3 style="font-family:var(--font-heading);font-size:20px;color:var(--white);margin:0;">Membership Details</h3>
            </div>
            <div style="padding:24px;">
                <div class="row g-4">
                    <div class="col-md-4">
                        <div class="admin-form-label">Plan</div>
                        <div style="color:var(--white);font-size:16px;font-weight:500;"><?php echo clean($applicant['membership_plan']); ?></div>
                    </div>
                    <div class="col-md-4">
                        <div class="admin-form-label">Price</div>
                        <div style="color:var(--coral-red);font-size:16px;font-weight:500;">₦<?php echo number_format($applicant['plan_price']); ?></div>
                    </div>
                    <div class="col-md-4">
                        <div class="admin-form-label">Status</div>
                        <div><?php echo statusBadge($applicant['status']); ?></div>
                    </div>
                    <?php if ($membership): ?>
                    <div class="col-md-4">
                        <div class="admin-form-label">Start Date</div>
                        <div style="color:var(--white);font-size:15px;"><?php echo formatDate($membership['start_date']); ?></div>
                    </div>
                    <div class="col-md-4">
                        <div class="admin-form-label">Expiry Date</div>
                        <div style="color:var(--white);font-size:15px;"><?php echo formatDate($membership['end_date']); ?></div>
                    </div>
                    <div class="col-md-4">
                        <div class="admin-form-label">Duration</div>
                        <div style="color:var(--white);font-size:15px;"><?php echo $membership['duration_days']; ?> Days</div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Uploaded Documents -->
        <?php if ($applicant['passport_photo'] || $applicant['means_of_id']): ?>
        <div class="admin-table-wrapper mt-4">
            <div style="padding:20px 24px;border-bottom:1px solid var(--border-subtle);">
                <h3 style="font-family:var(--font-heading);font-size:20px;color:var(--white);margin:0;">Uploaded Documents</h3>
            </div>
            <div style="padding:24px;">
                <div class="row g-4">
                    <?php if ($applicant['passport_photo']): ?>
                    <div class="col-md-6">
                        <div class="admin-form-label">Passport Photo</div>
                        <img src="../<?php echo $applicant['passport_photo']; ?>" alt="Passport" style="max-width:200px;border-radius:4px;border:1px solid var(--border-subtle);margin-top:8px;">
                    </div>
                    <?php endif; ?>
                    <?php if ($applicant['means_of_id']): ?>
                    <div class="col-md-6">
                        <div class="admin-form-label">Means of ID</div>
                        <img src="../<?php echo $applicant['means_of_id']; ?>" alt="ID" style="max-width:200px;border-radius:4px;border:1px solid var(--border-subtle);margin-top:8px;">
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<div class="mt-4">
    <a href="applicants.php" class="admin-btn admin-btn-secondary admin-btn-sm">← Back to Applicants</a>
</div>

<?php require_once 'includes/footer.php'; ?>
