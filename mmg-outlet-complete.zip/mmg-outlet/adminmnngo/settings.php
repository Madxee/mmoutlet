<?php
/**
 * M.M.G OUTLET - Admin Settings
 * Manage gym info, pricing, social links, and security
 */

require_once 'includes/header.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_validate()) {
        $error = 'Invalid security token.';
    } else {
        $section = $_POST['section'] ?? '';
        
        if ($section === 'gym') {
            updateSetting('gym_name', trim($_POST['gym_name'] ?? ''));
            updateSetting('gym_motto', trim($_POST['gym_motto'] ?? ''));
            updateSetting('gym_address', trim($_POST['gym_address'] ?? ''));
            updateSetting('gym_phone', trim($_POST['gym_phone'] ?? ''));
            updateSetting('gym_email', trim($_POST['gym_email'] ?? ''));
            $success = 'Gym information updated successfully.';
        }
        
        if ($section === 'pricing') {
            updateSetting('registration_form_price', (int)($_POST['registration_form_price'] ?? 1000));
            updateSetting('daily_gym_price', (int)($_POST['daily_gym_price'] ?? 3000));
            updateSetting('one_month_price', (int)($_POST['one_month_price'] ?? 20000));
            updateSetting('three_month_price', (int)($_POST['three_month_price'] ?? 60000));
            $success = 'Pricing updated successfully.';
        }
        
        if ($section === 'social') {
            updateSetting('whatsapp_link', trim($_POST['whatsapp_link'] ?? ''));
            updateSetting('instagram_link', trim($_POST['instagram_link'] ?? ''));
            updateSetting('facebook_link', trim($_POST['facebook_link'] ?? ''));
            updateSetting('twitter_link', trim($_POST['twitter_link'] ?? ''));
            $success = 'Social links updated successfully.';
        }
        
        if ($section === 'security') {
            $currentPassword = $_POST['current_password'] ?? '';
            $newPassword = $_POST['new_password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';
            
            if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
                $error = 'All password fields are required.';
            } elseif ($newPassword !== $confirmPassword) {
                $error = 'New passwords do not match.';
            } elseif (strlen($newPassword) < 6) {
                $error = 'New password must be at least 6 characters.';
            } else {
                $admin = getCurrentAdmin();
                if ($admin && password_verify($currentPassword, $admin['password_hash'])) {
                    $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
                    dbExecute("UPDATE admins SET password_hash = ? WHERE id = ?", [$newHash, $_SESSION['admin_id']]);
                    $success = 'Password changed successfully.';
                    logAction($_SESSION['admin_id'], 'PASSWORD_CHANGE', 'Admin changed their password');
                } else {
                    $error = 'Current password is incorrect.';
                }
            }
        }
        
        if ($section === 'logo' && !empty($_FILES['logo']['tmp_name'])) {
            $result = uploadFile($_FILES['logo'], '', ['png'], 1048576);
            if ($result['success']) {
                updateSetting('gym_logo', $result['path']);
                $success = 'Logo updated successfully.';
            } else {
                $error = 'Logo upload failed: ' . $result['message'];
            }
        }
    }
}

// Get current settings
$settings = [];
$allSettings = dbFetchAll("SELECT setting_key, setting_value FROM settings");
foreach ($allSettings as $s) {
    $settings[$s['setting_key']] = $s['setting_value'];
}
?>

<?php if ($error): ?>
<div class="admin-alert admin-alert-error"><?php echo clean($error); ?></div>
<?php endif; ?>
<?php if ($success): ?>
<div class="admin-alert admin-alert-success"><?php echo clean($success); ?></div>
<?php endif; ?>

<div class="row g-4">
    <!-- Gym Information -->
    <div class="col-lg-6">
        <div class="admin-table-wrapper" style="padding:24px;">
            <h3 style="font-family:var(--font-heading);font-size:20px;color:var(--white);margin-bottom:20px;">Gym Information</h3>
            <form method="POST">
                <?php echo csrfField(); ?>
                <input type="hidden" name="section" value="gym">
                
                <div class="admin-form-group">
                    <label class="admin-form-label">Gym Name</label>
                    <input type="text" name="gym_name" class="admin-form-input" value="<?php echo clean($settings['gym_name'] ?? ''); ?>" required>
                </div>
                <div class="admin-form-group">
                    <label class="admin-form-label">Motto</label>
                    <input type="text" name="gym_motto" class="admin-form-input" value="<?php echo clean($settings['gym_motto'] ?? ''); ?>">
                </div>
                <div class="admin-form-group">
                    <label class="admin-form-label">Address</label>
                    <textarea name="gym_address" class="admin-form-textarea"><?php echo clean($settings['gym_address'] ?? ''); ?></textarea>
                </div>
                <div class="admin-form-group">
                    <label class="admin-form-label">Phone</label>
                    <input type="text" name="gym_phone" class="admin-form-input" value="<?php echo clean($settings['gym_phone'] ?? ''); ?>">
                </div>
                <div class="admin-form-group">
                    <label class="admin-form-label">Email</label>
                    <input type="email" name="gym_email" class="admin-form-input" value="<?php echo clean($settings['gym_email'] ?? ''); ?>">
                </div>
                <button type="submit" class="admin-btn admin-btn-primary">Save Changes</button>
            </form>
        </div>
    </div>
    
    <!-- Pricing -->
    <div class="col-lg-6">
        <div class="admin-table-wrapper" style="padding:24px;">
            <h3 style="font-family:var(--font-heading);font-size:20px;color:var(--white);margin-bottom:20px;">Pricing Plans</h3>
            <form method="POST">
                <?php echo csrfField(); ?>
                <input type="hidden" name="section" value="pricing">
                
                <div class="admin-form-group">
                    <label class="admin-form-label">Registration Form (₦)</label>
                    <input type="number" name="registration_form_price" class="admin-form-input" value="<?php echo (int)($settings['registration_form_price'] ?? 1000); ?>" required>
                </div>
                <div class="admin-form-group">
                    <label class="admin-form-label">Daily Gym (₦)</label>
                    <input type="number" name="daily_gym_price" class="admin-form-input" value="<?php echo (int)($settings['daily_gym_price'] ?? 3000); ?>" required>
                </div>
                <div class="admin-form-group">
                    <label class="admin-form-label">One Month (₦)</label>
                    <input type="number" name="one_month_price" class="admin-form-input" value="<?php echo (int)($settings['one_month_price'] ?? 20000); ?>" required>
                </div>
                <div class="admin-form-group">
                    <label class="admin-form-label">Three Months (₦)</label>
                    <input type="number" name="three_month_price" class="admin-form-input" value="<?php echo (int)($settings['three_month_price'] ?? 60000); ?>" required>
                </div>
                <button type="submit" class="admin-btn admin-btn-primary">Update Pricing</button>
            </form>
        </div>
    </div>
    
    <!-- Social Links -->
    <div class="col-lg-6">
        <div class="admin-table-wrapper" style="padding:24px;">
            <h3 style="font-family:var(--font-heading);font-size:20px;color:var(--white);margin-bottom:20px;">Social Media Links</h3>
            <form method="POST">
                <?php echo csrfField(); ?>
                <input type="hidden" name="section" value="social">
                
                <div class="admin-form-group">
                    <label class="admin-form-label">WhatsApp Link</label>
                    <input type="url" name="whatsapp_link" class="admin-form-input" value="<?php echo clean($settings['whatsapp_link'] ?? ''); ?>" placeholder="https://wa.me/...">
                </div>
                <div class="admin-form-group">
                    <label class="admin-form-label">Instagram</label>
                    <input type="url" name="instagram_link" class="admin-form-input" value="<?php echo clean($settings['instagram_link'] ?? ''); ?>">
                </div>
                <div class="admin-form-group">
                    <label class="admin-form-label">Facebook</label>
                    <input type="url" name="facebook_link" class="admin-form-input" value="<?php echo clean($settings['facebook_link'] ?? ''); ?>">
                </div>
                <div class="admin-form-group">
                    <label class="admin-form-label">Twitter / X</label>
                    <input type="url" name="twitter_link" class="admin-form-input" value="<?php echo clean($settings['twitter_link'] ?? ''); ?>">
                </div>
                <button type="submit" class="admin-btn admin-btn-primary">Save Links</button>
            </form>
        </div>
    </div>
    
    <!-- Change Password -->
    <div class="col-lg-6">
        <div class="admin-table-wrapper" style="padding:24px;">
            <h3 style="font-family:var(--font-heading);font-size:20px;color:var(--white);margin-bottom:20px;">Change Password</h3>
            <form method="POST">
                <?php echo csrfField(); ?>
                <input type="hidden" name="section" value="security">
                
                <div class="admin-form-group">
                    <label class="admin-form-label">Current Password</label>
                    <input type="password" name="current_password" class="admin-form-input" required>
                </div>
                <div class="admin-form-group">
                    <label class="admin-form-label">New Password</label>
                    <input type="password" name="new_password" class="admin-form-input" required minlength="6">
                </div>
                <div class="admin-form-group">
                    <label class="admin-form-label">Confirm New Password</label>
                    <input type="password" name="confirm_password" class="admin-form-input" required minlength="6">
                </div>
                <button type="submit" class="admin-btn admin-btn-primary">Change Password</button>
            </form>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
