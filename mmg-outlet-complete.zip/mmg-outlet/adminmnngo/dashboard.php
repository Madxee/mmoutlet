<?php
/**
 * M.M.G OUTLET - Admin Dashboard
 * Overview with statistics, charts, and recent activity
 */

require_once 'includes/header.php';

// Get statistics
$totalApplicants = countApplicants();
$verifiedMembers = countApplicants('Approved');
$pendingApps = countApplicants('Pending');
$totalRevenue = getTotalRevenue();
$recentApplicants = getRecentRegistrations(10);

// Get monthly revenue for chart
$monthlyRevenue = dbFetchAll(
    "SELECT 
        DATE_FORMAT(applied_at, '%Y-%m') as month,
        DATE_FORMAT(applied_at, '%b %Y') as month_label,
        COALESCE(SUM(plan_price), 0) as revenue,
        COUNT(*) as count
     FROM applicants 
     WHERE status = 'Approved' AND applied_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
     GROUP BY DATE_FORMAT(applied_at, '%Y-%m')
     ORDER BY month ASC"
);

// Fill missing months
$chartLabels = [];
$chartRevenue = [];
$chartCounts = [];
for ($i = 5; $i >= 0; $i--) {
    $month = date('Y-m', strtotime("-{$i} months"));
    $label = date('M Y', strtotime("-{$i} months"));
    $found = false;
    foreach ($monthlyRevenue as $mr) {
        if ($mr['month'] === $month) {
            $chartLabels[] = $label;
            $chartRevenue[] = (float)$mr['revenue'];
            $chartCounts[] = (int)$mr['count'];
            $found = true;
            break;
        }
    }
    if (!$found) {
        $chartLabels[] = $label;
        $chartRevenue[] = 0;
        $chartCounts[] = 0;
    }
}

// Today's registrations
$todayCount = dbFetch("SELECT COUNT(*) as c FROM applicants WHERE DATE(applied_at) = CURDATE()");
$todayCount = $todayCount ? (int)$todayCount['c'] : 0;

// This month registrations
$monthCount = dbFetch("SELECT COUNT(*) as c FROM applicants WHERE MONTH(applied_at) = MONTH(CURDATE()) AND YEAR(applied_at) = YEAR(CURDATE())");
$monthCount = $monthCount ? (int)$monthCount['c'] : 0;
?>

<!-- Stat Cards -->
<div class="row g-4 mb-4">
    <div class="col-lg-3 col-md-6">
        <div class="admin-stat-card">
            <div class="admin-stat-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            </div>
            <div class="admin-stat-value" style="font-family:var(--font-mono);"><?php echo number_format($totalApplicants); ?></div>
            <div class="admin-stat-label">Total Applicants</div>
            <div class="admin-stat-trend up">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
                +<?php echo $todayCount; ?> today
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="admin-stat-card">
            <div class="admin-stat-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><polyline points="17 11 19 13 23 9"/></svg>
            </div>
            <div class="admin-stat-value" style="font-family:var(--font-mono);color:var(--jade-green);"><?php echo number_format($verifiedMembers); ?></div>
            <div class="admin-stat-label">Verified Members</div>
            <div class="admin-stat-trend up">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
                Active
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="admin-stat-card">
            <div class="admin-stat-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            </div>
            <div class="admin-stat-value" style="font-family:var(--font-mono);color:#FF9800;"><?php echo number_format($pendingApps); ?></div>
            <div class="admin-stat-label">Pending Applications</div>
            <div class="admin-stat-trend <?php echo $pendingApps > 0 ? 'down' : 'up'; ?>">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                Needs review
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="admin-stat-card">
            <div class="admin-stat-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            </div>
            <div class="admin-stat-value" style="font-family:var(--font-mono);color:var(--gold-accent);">₦<?php echo number_format($totalRevenue); ?></div>
            <div class="admin-stat-label">Total Revenue</div>
            <div class="admin-stat-trend up">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
                +<?php echo $monthCount; ?> this month
            </div>
        </div>
    </div>
</div>

<!-- Charts & Recent -->
<div class="row g-4">
    <!-- Revenue Chart -->
    <div class="col-lg-7">
        <div class="admin-table-wrapper" style="padding:24px;">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 style="font-family:var(--font-heading);font-size:20px;color:var(--white);margin:0;">Revenue Overview</h3>
                <span style="font-size:12px;color:var(--ash-gray);">Last 6 Months</span>
            </div>
            <canvas id="revenueChart" height="180"></canvas>
        </div>
    </div>
    
    <!-- Recent Registrations -->
    <div class="col-lg-5">
        <div class="admin-table-wrapper">
            <div class="d-flex justify-content-between align-items-center p-4 pb-0">
                <h3 style="font-family:var(--font-heading);font-size:20px;color:var(--white);margin:0;">Recent Registrations</h3>
                <a href="applicants.php" class="admin-btn admin-btn-sm admin-btn-secondary">View All</a>
            </div>
            <div class="table-responsive">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Plan</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentApplicants as $ra): ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <div style="width:32px;height:32px;background:linear-gradient(135deg,var(--coral-red),var(--signal-red));border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;color:#fff;">
                                        <?php echo strtoupper(substr($ra['full_name'], 0, 1)); ?>
                                    </div>
                                    <span class="cell-name" style="font-size:13px;"><?php echo clean($ra['full_name']); ?></span>
                                </div>
                            </td>
                            <td style="font-size:13px;"><?php echo clean($ra['membership_plan']); ?></td>
                            <td><?php echo statusBadge($ra['status']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($recentApplicants)): ?>
                        <tr>
                            <td colspan="3" style="text-align:center;padding:24px;color:var(--ash-gray);">No registrations yet</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row g-4 mt-2">
    <div class="col-12">
        <div class="admin-table-wrapper" style="padding:24px;">
            <h3 style="font-family:var(--font-heading);font-size:20px;color:var(--white);margin-bottom:20px;">Quick Actions</h3>
            <div class="row g-3">
                <div class="col-lg-3 col-md-6">
                    <a href="applicants.php" class="d-flex align-items-center gap-3 p-3 text-decoration-none" style="background:var(--input-bg);border:1px solid var(--border-subtle);border-radius:6px;color:var(--white);transition:all 0.2s ease;" onmouseover="this.style.borderColor='var(--coral-red)'" onmouseout="this.style.borderColor='var(--border-subtle)'">
                        <div style="width:44px;height:44px;background:rgba(255,82,82,0.1);border-radius:8px;display:flex;align-items:center;justify-content:center;color:var(--coral-red);">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                        </div>
                        <div>
                            <div style="font-size:14px;font-weight:600;">Manage Applicants</div>
                            <div style="font-size:12px;color:var(--ash-gray);">Review & approve applications</div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <a href="reports.php" class="d-flex align-items-center gap-3 p-3 text-decoration-none" style="background:var(--input-bg);border:1px solid var(--border-subtle);border-radius:6px;color:var(--white);transition:all 0.2s ease;" onmouseover="this.style.borderColor='var(--gold-accent)'" onmouseout="this.style.borderColor='var(--border-subtle)'">
                        <div style="width:44px;height:44px;background:rgba(212,168,67,0.1);border-radius:8px;display:flex;align-items:center;justify-content:center;color:var(--gold-accent);">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
                        </div>
                        <div>
                            <div style="font-size:14px;font-weight:600;">Generate Reports</div>
                            <div style="font-size:12px;color:var(--ash-gray);">Income & member reports</div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <a href="settings.php" class="d-flex align-items-center gap-3 p-3 text-decoration-none" style="background:var(--input-bg);border:1px solid var(--border-subtle);border-radius:6px;color:var(--white);transition:all 0.2s ease;" onmouseover="this.style.borderColor='var(--jade-green)'" onmouseout="this.style.borderColor='var(--border-subtle)'">
                        <div style="width:44px;height:44px;background:rgba(46,125,111,0.1);border-radius:8px;display:flex;align-items:center;justify-content:center;color:var(--jade-green);">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                        </div>
                        <div>
                            <div style="font-size:14px;font-weight:600;">Settings</div>
                            <div style="font-size:12px;color:var(--ash-gray);">Configure gym & pricing</div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <a href="applicants.php?status=Approved" class="d-flex align-items-center gap-3 p-3 text-decoration-none" style="background:var(--input-bg);border:1px solid var(--border-subtle);border-radius:6px;color:var(--white);transition:all 0.2s ease;" onmouseover="this.style.borderColor='#2196F3'" onmouseout="this.style.borderColor='var(--border-subtle)'">
                        <div style="width:44px;height:44px;background:rgba(33,150,243,0.1);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#2196F3;">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><polyline points="17 11 19 13 23 9"/></svg>
                        </div>
                        <div>
                            <div style="font-size:14px;font-weight:600;">View Members</div>
                            <div style="font-size:12px;color:var(--ash-gray);"><?php echo number_format($verifiedMembers); ?> active members</div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Revenue Chart
const ctx = document.getElementById('revenueChart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($chartLabels); ?>,
        datasets: [{
            label: 'Revenue (₦)',
            data: <?php echo json_encode($chartRevenue); ?>,
            borderColor: '#FF5252',
            backgroundColor: 'rgba(255, 82, 82, 0.1)',
            borderWidth: 2,
            fill: true,
            tension: 0.4,
            pointBackgroundColor: '#FF5252',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            pointRadius: 4
        }, {
            label: 'Registrations',
            data: <?php echo json_encode($chartCounts); ?>,
            borderColor: '#D4A843',
            backgroundColor: 'transparent',
            borderWidth: 2,
            borderDash: [5, 5],
            fill: false,
            tension: 0.4,
            pointBackgroundColor: '#D4A843',
            yAxisID: 'y1'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { intersect: false, mode: 'index' },
        plugins: {
            legend: {
                labels: { color: '#C0C0C0', font: { family: 'Manrope', size: 12 } }
            }
        },
        scales: {
            x: {
                grid: { color: 'rgba(255,255,255,0.03)' },
                ticks: { color: '#595959', font: { family: 'Manrope', size: 11 } }
            },
            y: {
                grid: { color: 'rgba(255,255,255,0.03)' },
                ticks: { 
                    color: '#595959', 
                    font: { family: 'Manrope', size: 11 },
                    callback: function(v) { return '₦' + v.toLocaleString(); }
                }
            },
            y1: {
                position: 'right',
                grid: { display: false },
                ticks: { color: '#D4A843', font: { family: 'Manrope', size: 11 } }
            }
        }
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>
