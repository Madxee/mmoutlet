<?php
/**
 * M.M.G OUTLET - Admin Footer
 */
?>
        </main>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function toggleSidebar() {
        document.getElementById('adminSidebar').classList.toggle('active');
        document.getElementById('adminOverlay').classList.toggle('active');
        document.body.classList.toggle('sidebar-open');
    }
    
    // Auto-dismiss flash messages
    setTimeout(function() {
        document.querySelectorAll('.admin-alert').forEach(function(el) {
            el.style.transition = 'opacity 0.3s, transform 0.3s';
            el.style.opacity = '0';
            el.style.transform = 'translateY(-10px)';
            setTimeout(function() { el.remove(); }, 300);
        });
    }, 4000);
    
    // Confirm delete actions
    document.querySelectorAll('[data-confirm]').forEach(function(el) {
        el.addEventListener('click', function(e) {
            var message = this.getAttribute('data-confirm') || 'Are you sure?';
            if (!confirm(message)) {
                e.preventDefault();
            }
        });
    });
    </script>
</body>
</html>
