<?php
/**
 * M.M.G OUTLET - Admin Login Page
 * Secure admin access at /adminmnngo/
 */

require_once '../includes/functions.php';
require_once '../includes/csrf.php';
startSecureSession();

// Already logged in?
if (isAdminLoggedIn()) {
    redirect('dashboard.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_validate()) {
        $error = 'Invalid security token. Please refresh and try again.';
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            $error = 'Please enter both username and password.';
        } else {
            $admin = dbFetch(
                "SELECT * FROM admins WHERE username = ? AND is_active = 1 LIMIT 1",
                [$username]
            );
            
            if ($admin && password_verify($password, $admin['password_hash'])) {
                // Update last login
                dbExecute(
                    "UPDATE admins SET last_login = NOW(), login_ip = ? WHERE id = ?",
                    [$_SERVER['REMOTE_ADDR'] ?? 'unknown', $admin['id']]
                );
                
                // Set session
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_username'] = $admin['username'];
                $_SESSION['admin_name'] = $admin['full_name'];
                $_SESSION['admin_role'] = $admin['role'];
                $_SESSION['admin_login_time'] = time();
                
                csrf_refresh();
                redirect('dashboard.php');
            } else {
                $error = 'Invalid username or password.';
                // Log failed attempt
                error_log("[MMG OUTLET] Failed login attempt for username: {$username} from IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Access | M.M.G OUTLET</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Manrope:wght@300;400;500;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --void-black: #050505;
            --charcoal: #111111;
            --coral-red: #FF5252;
            --signal-red: #D32F2F;
            --white: #FFFFFF;
            --ice-gray: #C0C0C0;
            --ash-gray: #595959;
            --gold-accent: #D4A843;
            --dark-card: #151515;
            --input-bg: #1C1C1C;
            --border-subtle: rgba(255,255,255,0.06);
            --font-heading: 'Instrument Serif', serif;
            --font-body: 'Manrope', sans-serif;
        }
        * { margin:0;padding:0;box-sizing:border-box; }
        body {
            font-family: var(--font-body);
            background: var(--void-black);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--white);
        }
        .login-bg {
            position: fixed;
            top: 0;left:0;right:0;bottom:0;
            background: url('../assets/images/hero-bg.jpg') center/cover no-repeat;
            opacity: 0.15;
            z-index: 0;
        }
        .login-overlay {
            position: fixed;
            top:0;left:0;right:0;bottom:0;
            background: radial-gradient(ellipse at center, rgba(5,5,5,0.7) 0%, rgba(5,5,5,0.95) 100%);
            z-index: 0;
        }
        .login-card {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 420px;
            background: rgba(21,21,21,0.8);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid var(--border-subtle);
            padding: 48px 40px;
        }
        .login-logo {
            text-align: center;
            margin-bottom: 32px;
        }
        .login-logo img {
            height: 80px;
            width: auto;
            margin-bottom: 16px;
        }
        .login-logo h2 {
            font-family: var(--font-heading);
            font-size: 24px;
            font-weight: 400;
            color: var(--white);
            text-transform: uppercase;
            letter-spacing: -0.5px;
        }
        .login-logo p {
            font-size: 12px;
            color: var(--ash-gray);
            text-transform: uppercase;
            letter-spacing: 0.15em;
            margin-top: 4px;
        }
        .login-input {
            width: 100%;
            padding: 14px 16px;
            background: var(--input-bg);
            border: 1px solid var(--border-subtle);
            border-radius: 8px;
            color: var(--white);
            font-family: var(--font-body);
            font-size: 15px;
            outline: none;
            transition: all 0.3s ease;
            margin-bottom: 16px;
        }
        .login-input:focus {
            border-color: var(--coral-red);
            box-shadow: 0 0 0 3px rgba(255,82,82,0.15);
        }
        .login-input::placeholder {
            color: var(--ash-gray);
        }
        .login-btn {
            width: 100%;
            padding: 14px;
            background: var(--coral-red);
            color: var(--white);
            border: none;
            font-family: var(--font-body);
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 8px;
        }
        .login-btn:hover {
            background: var(--signal-red);
        }
        .login-error {
            background: rgba(211,47,47,0.15);
            border: 1px solid rgba(211,47,47,0.3);
            color: var(--coral-red);
            padding: 12px 16px;
            font-size: 14px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .login-footer {
            text-align: center;
            margin-top: 24px;
            font-size: 12px;
            color: var(--ash-gray);
        }
        .gold-line {
            height: 2px;
            background: linear-gradient(90deg, transparent, var(--gold-accent), transparent);
            margin-bottom: 24px;
        }
        @keyframes fadeIn {
            from { opacity:0; transform:translateY(20px); }
            to { opacity:1; transform:translateY(0); }
        }
        .login-card {
            animation: fadeIn 0.6s ease;
        }
    </style>
</head>
<body>
    <div class="login-bg"></div>
    <div class="login-overlay"></div>
    
    <div class="login-card">
        <div class="login-logo">
            <img src="../assets/images/logo.png" alt="M.M.G OUTLET">
            <h2>Admin Access</h2>
            <p>M.M.G OUTLET Management System</p>
        </div>
        
        <div class="gold-line"></div>
        
        <?php if ($error): ?>
        <div class="login-error"><?php echo clean($error); ?></div>
        <?php endif; ?>
        
        <form method="POST" action="index.php">
            <?php echo csrfField(); ?>
            <input type="text" name="username" class="login-input" placeholder="Username" required autofocus autocomplete="username">
            <input type="password" name="password" class="login-input" placeholder="Password" required autocomplete="current-password">
            <button type="submit" class="login-btn">LOGIN</button>
        </form>
        
        <div class="login-footer">
            <p>Default: admin / admin123</p>
            <p style="margin-top:8px;">&copy; <?php echo date('Y'); ?> M.M.G OUTLET</p>
        </div>
    </div>
</body>
</html>
