<?php
/**
 * M.M.G OUTLET - ID Card Print System
 * Generate, preview, and print professional CR80 PVC ID cards
 */

require_once 'includes/header.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) {
    redirect('applicants.php');
}

$applicant = getApplicant($id);
if (!$applicant || $applicant['status'] !== 'Approved' || empty($applicant['member_id'])) {
    redirect('applicants.php?error=not_approved');
}

$membership = dbFetch("SELECT * FROM memberships WHERE applicant_id = ? LIMIT 1", [$id]);
$idCard = dbFetch("SELECT * FROM id_cards WHERE applicant_id = ? LIMIT 1", [$id]);

$gymName = getSetting('gym_name', 'M.M.G OUTLET');
$gymMotto = getSetting('gym_motto', 'Strength • Discipline • Fitness');
$gymAddress = getSetting('gym_address', '305B Tudun Yola, Kano');
$gymPhone = getSetting('gym_phone', '+234 912 717 1928');
$gymEmail = getSetting('gym_email', 'info@mmgoutlet.com');

$photoUrl = $applicant['passport_photo'] ? '../' . $applicant['passport_photo'] : '../assets/images/logo.png';
$expiryDate = $membership ? formatDate($membership['end_date']) : 'N/A';
$issueDate = $membership ? formatDate($membership['start_date']) : formatDate(date('Y-m-d'));

// Update print count
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'print') {
    dbExecute("UPDATE id_cards SET print_count = print_count + 1, last_printed = NOW() WHERE applicant_id = ?", [$id]);
    logAction($_SESSION['admin_id'], 'PRINT_ID_CARD', "Printed ID card for member {$applicant['member_id']}");
}
?>

<style>
@media screen {
    .id-card-screen-container {
        display: flex;
        gap: 40px;
        justify-content: center;
        flex-wrap: wrap;
        padding: 20px;
    }
    .id-card-wrapper {
        width: 343px;
        height: 216px;
        position: relative;
    }
}

@media print {
    @page {
        size: 85.60mm 53.98mm;
        margin: 0 !important;
    }
    body * {
        visibility: hidden !important;
        margin: 0 !important;
        padding: 0 !important;
    }
    #id-card-print-area,
    #id-card-print-area * {
        visibility: visible !important;
    }
    #id-card-print-area {
        position: fixed !important;
        left: 0 !important;
        top: 0 !important;
        width: 85.60mm !important;
        height: 53.98mm !important;
        margin: 0 !important;
        padding: 0 !important;
        page-break-after: avoid;
    }
    .admin-sidebar,
    .admin-topbar,
    .admin-content > *:not(#id-card-print-area) {
        display: none !important;
    }
}
</style>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
            <div>
                <a href="applicants.php" class="admin-btn admin-btn-secondary admin-btn-sm">← Back</a>
                <a href="verify.php?id=<?php echo $applicant['id']; ?>" class="admin-btn admin-btn-secondary admin-btn-sm ms-2">View Profile</a>
            </div>
            <div class="d-flex gap-2">
                <form method="POST" style="display:inline;">
                    <?php echo csrfField(); ?>
                    <input type="hidden" name="action" value="print">
                    <button type="submit" class="admin-btn admin-btn-primary" onclick="setTimeout(function(){window.print();},100);return true;">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
                        Print Card
                    </button>
                </form>
                <button class="admin-btn admin-btn-gold" onclick="downloadCard()">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    Download PDF
                </button>
            </div>
        </div>
        
        <div class="id-card-screen-container">
            <!-- FRONT -->
            <div>
                <div style="text-align:center;margin-bottom:12px;">
                    <span style="font-size:12px;color:var(--ash-gray);text-transform:uppercase;letter-spacing:0.1em;">Front Side</span>
                </div>
                <div class="id-card-wrapper">
                    <div id="card-front" style="width:100%;height:100%;background:linear-gradient(135deg,#0a0a0a 0%,#1a1510 50%,#0a0a0a 100%);border:2px solid #D4A843;border-radius:12px;overflow:hidden;position:relative;box-shadow:0 8px 32px rgba(0,0,0,0.5);">
                        <!-- Gold diagonal stripe -->
                        <div style="position:absolute;top:-40px;right:-60px;width:180px;height:180px;background:linear-gradient(135deg,rgba(255,82,82,0.12),transparent 70%);border-radius:0 0 0 100%;z-index:0;"></div>
                        <div style="position:absolute;bottom:0;left:0;right:0;height:3px;background:linear-gradient(90deg,transparent,#D4A843,transparent);z-index:2;"></div>
                        
                        <!-- Header -->
                        <div style="position:relative;z-index:1;padding:10px 14px;display:flex;align-items:center;gap:10px;border-bottom:1px solid rgba(212,168,67,0.25);">
                            <img src="../assets/images/logo.png" alt="" style="height:28px;width:auto;">
                            <div>
                                <div style="font-family:var(--font-heading);font-size:11px;color:#D4A843;text-transform:uppercase;letter-spacing:0.15em;font-weight:400;">M.M.G OUTLET</div>
                                <div style="font-size:7px;color:#595959;letter-spacing:0.1em;">MEMBERSHIP CARD</div>
                            </div>
                            <div style="margin-left:auto;font-family:var(--font-mono);font-size:9px;color:#D4A843;background:rgba(212,168,67,0.1);padding:2px 8px;border-radius:3px;">VIP</div>
                        </div>
                        
                        <!-- Body -->
                        <div style="position:relative;z-index:1;padding:12px 14px;display:flex;gap:14px;">
                            <!-- Photo -->
                            <div style="flex-shrink:0;">
                                <div style="width:72px;height:72px;border-radius:50%;border:2px solid #D4A843;overflow:hidden;background:#111;">
                                    <img src="<?php echo $photoUrl; ?>" alt="" style="width:100%;height:100%;object-fit:cover;">
                                </div>
                            </div>
                            <!-- Info -->
                            <div style="flex:1;min-width:0;">
                                <div style="font-family:var(--font-heading);font-size:15px;color:#FFFFFF;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:3px;">
                                    <?php echo clean(strtoupper($applicant['full_name'])); ?>
                                </div>
                                <div style="font-family:var(--font-mono);font-size:13px;color:#D4A843;letter-spacing:2px;margin-bottom:3px;font-weight:700;">
                                    <?php echo $applicant['member_id']; ?>
                                </div>
                                <div style="font-size:9px;color:#595959;margin-bottom:6px;">
                                    <span style="color:#888;">ISSUED:</span> <?php echo $issueDate; ?> 
                                    <span style="color:#888;margin-left:8px;">EXP:</span> <span style="color:#FF5252;"><?php echo $expiryDate; ?></span>
                                </div>
                                <div style="font-size:8px;color:#595959;text-transform:uppercase;letter-spacing:0.05em;">
                                    <?php echo clean($applicant['membership_plan']); ?> — ₦<?php echo number_format($applicant['plan_price']); ?>
                                </div>
                            </div>
                        </div>
                        
                        <!-- QR Code -->
                        <div style="position:absolute;bottom:16px;right:14px;z-index:2;">
                            <div id="mini-qr" style="width:48px;height:48px;background:#fff;padding:3px;border-radius:4px;"></div>
                        </div>
                        
                        <!-- Footer motto -->
                        <div style="position:absolute;bottom:8px;left:14px;z-index:2;font-size:7px;color:#595959;letter-spacing:0.08em;text-transform:uppercase;">
                            <?php echo clean($gymMotto); ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- BACK -->
            <div>
                <div style="text-align:center;margin-bottom:12px;">
                    <span style="font-size:12px;color:var(--ash-gray);text-transform:uppercase;letter-spacing:0.1em;">Back Side</span>
                </div>
                <div class="id-card-wrapper">
                    <div style="width:100%;height:100%;background:linear-gradient(135deg,#111 0%,#1a1a1a 100%);border:2px solid #D4A843;border-radius:12px;overflow:hidden;position:relative;box-shadow:0 8px 32px rgba(0,0,0,0.5);">
                        <!-- Top gold line -->
                        <div style="position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,transparent,#D4A843,transparent);"></div>
                        
                        <div style="padding:14px 16px;position:relative;z-index:1;">
                            <!-- Header -->
                            <div style="text-align:center;margin-bottom:10px;padding-bottom:8px;border-bottom:1px solid rgba(212,168,67,0.2);">
                                <div style="font-family:var(--font-heading);font-size:13px;color:#D4A843;">M.M.G OUTLET</div>
                                <div style="font-size:7px;color:#595959;letter-spacing:0.1em;">MEMBERSHIP CARD — BACK</div>
                            </div>
                            
                            <!-- Content -->
                            <div style="font-size:8px;color:#C0C0C0;line-height:1.7;">
                                <div style="margin-bottom:8px;">
                                    <strong style="color:#fff;font-size:9px;display:block;margin-bottom:2px;">Emergency Contact</strong>
                                    <?php echo clean($applicant['emergency_contact'] ?: 'N/A'); ?>
                                </div>
                                
                                <div style="margin-bottom:8px;">
                                    <strong style="color:#fff;font-size:9px;display:block;margin-bottom:2px;">Terms & Conditions</strong>
                                    1. This card remains property of M.M.G OUTLET.<br>
                                    2. Card must be presented for gym entry.<br>
                                    3. Lost cards: Report immediately. Replacement fee applies.<br>
                                    4. Membership is non-transferable.
                                </div>
                                
                                <div>
                                    <strong style="color:#fff;font-size:9px;display:block;margin-bottom:2px;">Contact</strong>
                                    <?php echo clean($gymAddress); ?><br>
                                    Phone: <?php echo clean($gymPhone); ?><br>
                                    Email: <?php echo clean($gymEmail); ?>
                                </div>
                            </div>
                            
                            <!-- Signature area -->
                            <div style="margin-top:8px;padding-top:8px;border-top:1px solid rgba(255,255,255,0.06);display:flex;justify-content:space-between;align-items:flex-end;">
                                <div>
                                    <div style="width:80px;height:1px;background:#fff;margin-bottom:3px;"></div>
                                    <div style="font-size:7px;color:#595959;">Member Signature</div>
                                </div>
                                <div id="back-qr" style="width:32px;height:32px;background:#fff;padding:2px;border-radius:2px;"></div>
                            </div>
                        </div>
                        
                        <!-- Bottom footer -->
                        <div style="position:absolute;bottom:6px;left:0;right:0;text-align:center;font-size:6px;color:#595959;letter-spacing:0.05em;">
                            If found, please return to M.M.G OUTLET or contact <?php echo clean($gymPhone); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Print Area (Hidden, used for printing at exact CR80 size) -->
        <div id="id-card-print-area" style="display:none;">
            <!-- This will be populated via JavaScript for exact CR80 printing -->
        </div>
    </div>
</div>

<script>
// Generate QR codes
var qrData = <?php echo json_encode((isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/verify-member.php?mid=' . urlencode($applicant['member_id'])); ?>;

new QRCode(document.getElementById('mini-qr'), {
    text: qrData,
    width: 42,
    height: 42,
    colorDark: '#000000',
    colorLight: '#ffffff',
    correctLevel: QRCode.CorrectLevel.M
});

new QRCode(document.getElementById('back-qr'), {
    text: qrData,
    width: 28,
    height: 28,
    colorDark: '#000000',
    colorLight: '#ffffff',
    correctLevel: QRCode.CorrectLevel.M
});

// Download as image
downloadCard = function() {
    alert('To download: Right-click on the card image and select "Save Image As", or use the Print button and select "Save as PDF" as the printer.');
};
</script>

<?php require_once 'includes/footer.php'; ?>
