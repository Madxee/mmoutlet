<?php
/**
 * M.M.G OUTLET - Admin Applicants Management
 * View, search, filter, approve, reject, edit, delete applicants
 */

require_once 'includes/header.php';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!csrf_validate()) {
        redirect('applicants.php?error=csrf');
    }
    
    $action = $_POST['action'];
    $applicantId = (int)($_POST['applicant_id'] ?? 0);
    
    if ($action === 'approve' && $applicantId) {
        $applicant = getApplicant($applicantId);
        if ($applicant && $applicant['status'] === 'Pending') {
            $memberId = generateMemberId();
            $endDate = calculateEndDate($applicant['membership_plan']);
            $duration = getPlanDuration($applicant['membership_plan']);
            
            dbExecute("UPDATE applicants SET status = 'Approved', member_id = ?, approved_at = NOW(), approved_by = ? WHERE id = ?", 
                      [$memberId, $_SESSION['admin_id'], $applicantId]);
            
            dbInsert("INSERT INTO memberships (applicant_id, member_id, plan_name, plan_price, start_date, end_date, duration_days) 
                      VALUES (?, ?, ?, ?, CURDATE(), ?, ?)",
                      [$applicantId, $memberId, $applicant['membership_plan'], $applicant['plan_price'], $endDate, $duration]);
            
            dbInsert("INSERT INTO id_cards (applicant_id, member_id) VALUES (?, ?)", [$applicantId, $memberId]);
            
            dbExecute("UPDATE payments SET member_id = ?, payment_status = 'Paid', paid_at = NOW() WHERE applicant_id = ?",
                      [$memberId, $applicantId]);
            
            logAction($_SESSION['admin_id'], 'APPROVE_APPLICANT', "Approved applicant #{$applicantId}, assigned Member ID: {$memberId}");
            redirect('applicants.php?status=Approved', 'Applicant approved successfully! Member ID: ' . $memberId, 'success');
        }
    }
    
    if ($action === 'reject' && $applicantId) {
        dbExecute("UPDATE applicants SET status = 'Rejected', updated_at = NOW() WHERE id = ?", [$applicantId]);
        logAction($_SESSION['admin_id'], 'REJECT_APPLICANT', "Rejected applicant #{$applicantId}");
        redirect('applicants.php', 'Applicant rejected.', 'success');
    }
    
    if ($action === 'suspend' && $applicantId) {
        dbExecute("UPDATE applicants SET status = 'Suspended', updated_at = NOW() WHERE id = ?", [$applicantId]);
        dbExecute("UPDATE memberships SET status = 'Suspended' WHERE applicant_id = ?", [$applicantId]);
        logAction($_SESSION['admin_id'], 'SUSPEND_MEMBER', "Suspended applicant #{$applicantId}");
        redirect('applicants.php', 'Member suspended.', 'success');
    }
    
    if ($action === 'delete' && $applicantId) {
        dbExecute("DELETE FROM applicants WHERE id = ?", [$applicantId]);
        logAction($_SESSION['admin_id'], 'DELETE_APPLICANT', "Deleted applicant #{$applicantId}");
        redirect('applicants.php', 'Applicant deleted permanently.', 'success');
    }
}

// Filters
$statusFilter = $_GET['status'] ?? '';
$searchFilter = trim($_GET['search'] ?? '');
$planFilter = $_GET['plan'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = (int)getSetting('items_per_page', '20');
$offset = ($page - 1) * $perPage;

// Build query conditions
$where = "WHERE 1=1";
$params = [];

if ($statusFilter && in_array($statusFilter, ['Pending', 'Approved', 'Rejected', 'Suspended'])) {
    $where .= " AND status = ?";
    $params[] = $statusFilter;
}
if ($searchFilter) {
    $where .= " AND (full_name LIKE ? OR phone_number LIKE ? OR email LIKE ? OR member_id LIKE ?)";
    $searchParam = "%{$searchFilter}%";
    $params = array_merge($params, [$searchParam, $searchParam, $searchParam, $searchParam]);
}
if ($planFilter) {
    $where .= " AND membership_plan = ?";
    $params[] = $planFilter;
}

// Get total count
$countSql = "SELECT COUNT(*) as total FROM applicants {$where}";
$totalResult = dbFetch($countSql, $params);
$totalRecords = $totalResult ? (int)$totalResult['total'] : 0;
$totalPages = max(1, ceil($totalRecords / $perPage));

// Get applicants
$sql = "SELECT * FROM applicants {$where} ORDER BY applied_at DESC LIMIT ? OFFSET ?";
$queryParams = array_merge($params, [$perPage, $offset]);
$applicants = dbFetchAll($sql, $queryParams);

// Base URL for pagination
$baseUrl = 'applicants.php?1=1';
if ($statusFilter) $baseUrl .= '&status=' . urlencode($statusFilter);
if ($searchFilter) $baseUrl .= '&search=' . urlencode($searchFilter);
if ($planFilter) $baseUrl .= '&plan=' . urlencode($planFilter);
?>

<!-- Filters -->
<div class="admin-filter-bar">
    <div class="admin-search-box">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <form method="GET" action="applicants.php" style="display:contents;">
            <input type="text" name="search" placeholder="Search name, phone, email, member ID..." value="<?php echo clean($searchFilter); ?>">
        </form>
    </div>
    <form method="GET" action="applicants.php" class="d-flex gap-2 flex-wrap" style="align-items:flex-end;">
        <input type="hidden" name="search" value="<?php echo clean($searchFilter); ?>">
        <select name="status" class="admin-form-select" style="width:auto;min-width:140px;" onchange="this.form.submit()">
            <option value="">All Status</option>
            <option value="Pending" <?php echo $statusFilter === 'Pending' ? 'selected' : ''; ?>>Pending</option>
            <option value="Approved" <?php echo $statusFilter === 'Approved' ? 'selected' : ''; ?>>Approved</option>
            <option value="Rejected" <?php echo $statusFilter === 'Rejected' ? 'selected' : ''; ?>>Rejected</option>
            <option value="Suspended" <?php echo $statusFilter === 'Suspended' ? 'selected' : ''; ?>>Suspended</option>
        </select>
        <select name="plan" class="admin-form-select" style="width:auto;min-width:160px;" onchange="this.form.submit()">
            <option value="">All Plans</option>
            <option value="Registration Form" <?php echo $planFilter === 'Registration Form' ? 'selected' : ''; ?>>Registration Form</option>
            <option value="Daily Gym" <?php echo $planFilter === 'Daily Gym' ? 'selected' : ''; ?>>Daily Gym</option>
            <option value="One Month" <?php echo $planFilter === 'One Month' ? 'selected' : ''; ?>>One Month</option>
            <option value="Three Months" <?php echo $planFilter === 'Three Months' ? 'selected' : ''; ?>>Three Months</option>
        </select>
        <a href="applicants.php" class="admin-btn admin-btn-secondary admin-btn-sm">Reset</a>
    </form>
</div>

<!-- Applicants Table -->
<div class="admin-table-wrapper">
    <div class="table-responsive">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Contact</th>
                    <th>Plan</th>
                    <th>Applied</th>
                    <th>Status</th>
                    <th style="text-align:right;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($applicants as $app): ?>
                <tr>
                    <td class="cell-mono">#<?php echo $app['id']; ?></td>
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            <?php if ($app['passport_photo']): ?>
                            <img src="../<?php echo $app['passport_photo']; ?>" alt="" style="width:36px;height:36px;border-radius:50%;object-fit:cover;border:1px solid var(--border-subtle);">
                            <?php else: ?>
                            <div style="width:36px;height:36px;background:linear-gradient(135deg,var(--coral-red),var(--signal-red));border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:#fff;">
                                <?php echo strtoupper(substr($app['full_name'], 0, 1)); ?>
                            </div>
                            <?php endif; ?>
                            <div>
                                <div class="cell-name" style="font-size:14px;"><?php echo clean($app['full_name']); ?></div>
                                <?php if ($app['member_id']): ?>
                                <div class="cell-mono" style="color:var(--gold-accent);font-size:11px;"><?php echo $app['member_id']; ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div style="font-size:13px;"><?php echo clean($app['phone_number']); ?></div>
                        <?php if ($app['email']): ?>
                        <div style="font-size:11px;color:var(--ash-gray);"><?php echo clean($app['email']); ?></div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div style="font-size:13px;color:var(--white);"><?php echo clean($app['membership_plan']); ?></div>
                        <div style="font-size:12px;color:var(--coral-red);">₦<?php echo number_format($app['plan_price']); ?></div>
                    </td>
                    <td style="font-size:13px;"><?php echo formatDate($app['applied_at']); ?></td>
                    <td><?php echo statusBadge($app['status']); ?></td>
                    <td style="text-align:right;">
                        <div class="d-flex gap-1 justify-content-end">
                            <a href="verify.php?id=<?php echo $app['id']; ?>" class="admin-icon-btn view" title="View Details">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                            </a>
                            <?php if ($app['status'] === 'Pending'): ?>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Approve this applicant and generate Member ID?')">
                                <?php echo csrfField(); ?>
                                <input type="hidden" name="action" value="approve">
                                <input type="hidden" name="applicant_id" value="<?php echo $app['id']; ?>">
                                <button type="submit" class="admin-icon-btn approve" title="Approve">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                                </button>
                            </form>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Reject this applicant?')">
                                <?php echo csrfField(); ?>
                                <input type="hidden" name="action" value="reject">
                                <input type="hidden" name="applicant_id" value="<?php echo $app['id']; ?>">
                                <button type="submit" class="admin-icon-btn reject" title="Reject">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                                </button>
                            </form>
                            <?php endif; ?>
                            <?php if ($app['status'] === 'Approved'): ?>
                            <a href="print-id.php?id=<?php echo $app['id']; ?>" class="admin-icon-btn" title="Print ID Card" style="color:var(--gold-accent);" onmouseover="this.style.background='rgba(212,168,67,0.1)'" onmouseout="this.style.background='none'">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                            </a>
                            <?php endif; ?>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Permanently delete this applicant? This cannot be undone.')">
                                <?php echo csrfField(); ?>
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="applicant_id" value="<?php echo $app['id']; ?>">
                                <button type="submit" class="admin-icon-btn delete" title="Delete">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($applicants)): ?>
                <tr>
                    <td colspan="7" style="text-align:center;padding:48px;color:var(--ash-gray);font-size:15px;">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" style="margin-bottom:12px;opacity:0.5;"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                        <p>No applicants found matching your criteria.</p>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Pagination -->
<?php if ($totalPages > 1): ?>
<div style="margin-top:24px;">
    <?php echo pagination($page, $totalPages, $baseUrl); ?>
</div>
<?php endif; ?>

<!-- Summary -->
<div style="margin-top:16px;text-align:center;color:var(--ash-gray);font-size:13px;">
    Showing <?php echo count($applicants); ?> of <?php echo number_format($totalRecords); ?> records
</div>

<?php require_once 'includes/footer.php'; ?>
