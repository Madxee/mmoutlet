# M.M.G OUTLET - Installation Guide

## System Requirements

- PHP 7.4 or higher
- MySQL 5.7 or higher / MariaDB 10.3+
- Apache with mod_rewrite enabled
- cPanel hosting (shared hosting compatible)

## Installation Steps

### Step 1: Upload Files

1. Extract the ZIP file on your computer.
2. Upload all files and folders to your `public_html` directory using cPanel File Manager or FTP.
3. Ensure the following folder structure is maintained:

```
public_html/
├── index.php
├── about.php
├── membership.php
├── apply.php
├── contact.php
├── .htaccess
├── assets/
│   ├── css/
│   ├── js/
│   └── images/
├── uploads/
│   ├── passports/
│   └── ids/
├── database/
│   └── mmg_outlet.sql
├── includes/
│   ├── db.php
│   ├── functions.php
│   ├── csrf.php
│   ├── header.php
│   └── footer.php
└── adminmnngo/
    ├── index.php
    ├── dashboard.php
    ├── applicants.php
    ├── verify.php
    ├── print-id.php
    ├── reports.php
    ├── settings.php
    ├── logout.php
    ├── verify-member.php
    ├── includes/
    │   ├── header.php
    │   └── footer.php
    └── assets/
        └── css/
```

### Step 2: Create Database

1. Log in to your cPanel.
2. Go to **MySQL Database Wizard**.
3. Create a new database (e.g., `youruser_mmgoutlet`).
4. Create a new database user (e.g., `youruser_mmgadmin`).
5. Set a strong password for the user.
6. Add the user to the database with **ALL PRIVILEGES**.

### Step 3: Import Database

1. In cPanel, go to **phpMyAdmin**.
2. Select your newly created database.
3. Click on the **Import** tab.
4. Click **Choose File** and select the `database/mmg_outlet.sql` file from this project.
5. Click **Go** to import the database structure and default data.

### Step 4: Configure Database Connection

1. Open `includes/db.php` in the cPanel File Manager editor.
2. Update the database credentials at the top of the file:

```php
$db_host = 'localhost';          // Usually localhost
$db_name = 'youruser_mmgoutlet'; // Your database name
$db_user = 'youruser_mmgadmin';  // Your database username
$db_pass = 'your_password_here'; // Your database password
```

3. Save the file.

### Step 5: Set Folder Permissions

Ensure the following directories are writable (755 or 775):

```
uploads/
uploads/passports/
uploads/ids/
```

You can set permissions in cPanel File Manager by right-clicking each folder and selecting **Permissions**.

### Step 6: Access Your Website

1. Visit your domain: `https://yourdomain.com/`
2. The public website should load with all pages working.
3. Visit the admin panel: `https://yourdomain.com/adminmnngo/`

### Default Admin Login

- **Username:** `admin`
- **Password:** `admin123`

> **IMPORTANT:** Change the default password immediately after first login! Go to **Settings → Change Password**.

## Post-Installation

### Update Default Admin Password

1. Log in to the admin panel.
2. Navigate to **Settings**.
3. Scroll to **Change Password** section.
4. Enter `admin123` as the current password.
5. Enter your new secure password.
6. Click **Change Password**.

### Customize Gym Information

1. In the admin panel, go to **Settings**.
2. Update your gym name, address, phone, and email.
3. Update social media links.
4. Adjust pricing plans if needed.

### Upload Your Logo

1. Replace `assets/images/logo.png` with your own logo.
2. Keep the same filename or update the path in Settings.

## Important Security Notes

- The `.htaccess` file provides basic security protections.
- Always use HTTPS (SSL certificate recommended).
- Change the admin password immediately after installation.
- Keep your PHP and MySQL versions updated.
- The `uploads/` directory is protected from direct PHP execution.

## Troubleshooting

### 404 Errors
- Ensure Apache `mod_rewrite` is enabled.
- Check that `.htaccess` file was uploaded correctly.

### Database Connection Errors
- Verify database credentials in `includes/db.php`.
- Ensure database user has proper privileges.

### File Upload Errors
- Check that `uploads/passports/` and `uploads/ids/` are writable (chmod 755).
- Verify PHP `upload_max_filesize` is at least 2MB.

### Blank Pages
- Enable PHP error display temporarily by adding to `includes/db.php`:
  ```php
  ini_set('display_errors', 1);
  error_reporting(E_ALL);
  ```
- Check Apache error logs in cPanel.

## Support

For technical support, contact the development team or refer to the system documentation.

---

**M.M.G OUTLET** — Strength • Discipline • Fitness
