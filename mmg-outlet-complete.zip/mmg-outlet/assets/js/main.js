/**
 * M.M.G OUTLET - Main JavaScript
 * Animations, interactions, and effects
 */

(function() {
    'use strict';

    // Wait for DOM
    document.addEventListener('DOMContentLoaded', function() {
        initNavigation();
        initHeroAnimation();
        initScrollReveal();
        initPricingCards();
        initFileDropzones();
        initSmoothScroll();
    });

    // ============================================================
    // NAVIGATION
    // ============================================================
    function initNavigation() {
        const nav = document.getElementById('mainNav');
        const toggle = document.getElementById('navToggle');
        const menu = document.getElementById('navMenu');

        if (!nav || !toggle || !menu) return;

        // Scroll handler
        let lastScroll = 0;
        window.addEventListener('scroll', function() {
            const currentScroll = window.pageYOffset;

            // Add/remove scrolled class
            if (currentScroll > 50) {
                nav.classList.add('scrolled');
            } else {
                nav.classList.remove('scrolled');
            }

            // Hide/show nav on scroll direction
            if (currentScroll > lastScroll && currentScroll > 200) {
                nav.style.transform = 'translateY(-100%)';
            } else {
                nav.style.transform = 'translateY(0)';
            }
            lastScroll = currentScroll;
        });

        // Mobile toggle
        toggle.addEventListener('click', function() {
            toggle.classList.toggle('active');
            menu.classList.toggle('active');
            document.body.style.overflow = menu.classList.contains('active') ? 'hidden' : '';
        });

        // Close menu on link click
        menu.querySelectorAll('a').forEach(function(link) {
            link.addEventListener('click', function() {
                toggle.classList.remove('active');
                menu.classList.remove('active');
                document.body.style.overflow = '';
            });
        });
    }

    // ============================================================
    // HERO ANIMATION (Cinematic Sweep)
    // ============================================================
    function initHeroAnimation() {
        const heroTitle = document.querySelector('.mmg-hero-title');
        if (!heroTitle) return;

        // Split text into characters
        const text = heroTitle.textContent;
        heroTitle.innerHTML = '';
        
        const words = text.split(' ');
        words.forEach(function(word, wIndex) {
            const wordSpan = document.createElement('span');
            wordSpan.style.display = 'inline-block';
            wordSpan.style.whiteSpace = 'nowrap';
            
            for (let i = 0; i < word.length; i++) {
                const charSpan = document.createElement('span');
                charSpan.className = 'char';
                charSpan.textContent = word[i];
                charSpan.style.display = 'inline-block';
                charSpan.style.transformOrigin = '50% 50% -100px';
                wordSpan.appendChild(charSpan);
            }
            
            heroTitle.appendChild(wordSpan);
            
            if (wIndex < words.length - 1) {
                const space = document.createTextNode('\u00A0');
                heroTitle.appendChild(space);
            }
        });

        const chars = heroTitle.querySelectorAll('.char');
        
        // Set initial state
        gsap.set(chars, {
            opacity: 0,
            scale: 0,
            rotationY: 90,
            rotationX: 45,
            y: 100
        });

        // Animate in with stagger
        const tl = gsap.timeline({ delay: 0.5 });
        tl.to(chars, {
            opacity: 1,
            scale: 1,
            rotationY: 0,
            rotationX: 0,
            y: 0,
            duration: 1.2,
            ease: 'expo.out',
            stagger: 0.03
        });

        // Add glow after animation
        tl.add(function() {
            heroTitle.classList.add('glow-active');
        }, '+=0.5');

        // Animate subtitle
        const subtitle = document.querySelector('.mmg-hero-subtitle');
        if (subtitle) {
            gsap.set(subtitle, { opacity: 0, y: 30 });
            tl.to(subtitle, {
                opacity: 1,
                y: 0,
                duration: 0.8,
                ease: 'power2.out'
            }, '-=0.5');
        }

        // Animate CTA buttons
        const actions = document.querySelector('.mmg-hero-actions');
        if (actions) {
            gsap.set(actions, { opacity: 0, y: 20 });
            tl.to(actions, {
                opacity: 1,
                y: 0,
                duration: 0.6,
                ease: 'power2.out'
            }, '-=0.3');
        }
    }

    // ============================================================
    // SCROLL REVEAL
    // ============================================================
    function initScrollReveal() {
        const revealElements = document.querySelectorAll('.mmg-reveal');
        
        if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
            gsap.registerPlugin(ScrollTrigger);
            
            revealElements.forEach(function(el) {
                gsap.fromTo(el, 
                    { opacity: 0, y: 40 },
                    {
                        opacity: 1,
                        y: 0,
                        duration: 0.8,
                        ease: 'power2.out',
                        scrollTrigger: {
                            trigger: el,
                            start: 'top bottom-=100',
                            once: true
                        }
                    }
                );
            });

            // Also handle about image parallax
            const aboutImage = document.querySelector('.mmg-about-image');
            if (aboutImage) {
                gsap.to(aboutImage, {
                    scale: 1.05,
                    scrollTrigger: {
                        trigger: aboutImage.parentElement,
                        start: 'top bottom',
                        end: 'bottom top',
                        scrub: 1
                    }
                });
            }
        } else {
            // Fallback without GSAP
            revealElements.forEach(function(el) {
                el.classList.add('revealed');
            });
        }
    }

    // ============================================================
    // PRICING CARDS (Elastic Tilt)
    // ============================================================
    function initPricingCards() {
        const cards = document.querySelectorAll('.mmg-pricing-card');
        const scrambleChars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';

        cards.forEach(function(card) {
            const priceEl = card.querySelector('.mmg-pricing-price');
            if (!priceEl) return;

            const priceDefault = priceEl.dataset.priceDefault || priceEl.textContent;
            const priceHover = priceEl.dataset.priceHover || priceDefault;
            let lastX = 0, lastY = 0;
            let tiltFrame = null, scrambleFrame = null, scrambleActive = false;

            // Mouse move - 3D tilt
            card.addEventListener('mousemove', function(e) {
                const rect = card.getBoundingClientRect();
                const x = (e.clientX - rect.left) / rect.width;
                const y = (e.clientY - rect.top) / rect.height;
                
                const rotateX = (0.5 - y) * 8;
                const rotateY = (x - 0.5) * 8;
                
                lastX = rotateX;
                lastY = rotateY;
                
                if (tiltFrame) cancelAnimationFrame(tiltFrame);
                tiltFrame = requestAnimationFrame(function() {
                    card.style.transform = 'perspective(1000px) rotateX(' + lastX + 'deg) rotateY(' + lastY + 'deg) translateY(-4px)';
                    tiltFrame = null;
                });
            });

            // Mouse enter - start scramble
            card.addEventListener('mouseenter', function() {
                scrambleActive = true;
                
                function scrambleLoop() {
                    if (!scrambleActive) return;
                    let result = '';
                    for (let i = 0; i < priceHover.length; i++) {
                        if (priceHover[i] === '₦' || priceHover[i] === ',' || priceHover[i] === ' ') {
                            result += priceHover[i];
                        } else {
                            result += scrambleChars[Math.floor(Math.random() * scrambleChars.length)];
                        }
                    }
                    priceEl.textContent = result;
                    scrambleFrame = requestAnimationFrame(scrambleLoop);
                }
                scrambleLoop();
            });

            // Mouse leave - reset
            card.addEventListener('mouseleave', function() {
                scrambleActive = false;
                if (scrambleFrame) cancelAnimationFrame(scrambleFrame);
                priceEl.textContent = priceDefault;
                
                card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0)';
                card.style.transition = 'transform 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55)';
                
                setTimeout(function() {
                    card.style.transition = '';
                }, 600);
            });
        });
    }

    // ============================================================
    // FILE DROPZONES
    // ============================================================
    function initFileDropzones() {
        const dropzones = document.querySelectorAll('.mmg-file-dropzone');
        
        dropzones.forEach(function(zone) {
            const input = zone.querySelector('input[type="file"]');
            const text = zone.querySelector('.mmg-file-dropzone-text');
            const originalText = text ? text.innerHTML : '';
            
            if (!input) return;

            zone.addEventListener('click', function() {
                input.click();
            });

            zone.addEventListener('dragover', function(e) {
                e.preventDefault();
                zone.style.borderColor = '#FF5252';
                zone.style.background = 'rgba(255, 82, 82, 0.05)';
            });

            zone.addEventListener('dragleave', function() {
                zone.style.borderColor = '';
                zone.style.background = '';
            });

            zone.addEventListener('drop', function(e) {
                e.preventDefault();
                zone.style.borderColor = '';
                zone.style.background = '';
                
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    input.files = files;
                    updateDropzoneText(zone, text, files[0].name);
                }
            });

            input.addEventListener('change', function() {
                if (this.files.length > 0) {
                    updateDropzoneText(zone, text, this.files[0].name);
                }
            });
        });

        function updateDropzoneText(zone, text, filename) {
            if (text) {
                text.innerHTML = '<span style="color:#2E7D6F;">✓</span> ' + filename;
            }
            zone.style.borderColor = '#2E7D6F';
            zone.style.background = 'rgba(46, 125, 111, 0.05)';
        }
    }

    // ============================================================
    // SMOOTH SCROLL
    // ============================================================
    function initSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(function(anchor) {
            anchor.addEventListener('click', function(e) {
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const target = document.querySelector(targetId);
                if (target) {
                    e.preventDefault();
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    }

    // ============================================================
    // UTILITY FUNCTIONS
    // ============================================================
    
    // Flash message auto-dismiss
    window.dismissFlash = function(el) {
        if (el && el.parentElement) {
            el.parentElement.style.opacity = '0';
            el.parentElement.style.transform = 'translateX(100%)';
            setTimeout(function() {
                if (el.parentElement && el.parentElement.parentElement) {
                    el.parentElement.parentElement.removeChild(el.parentElement);
                }
            }, 300);
        }
    };

    // Auto-dismiss flash after 4 seconds
    setTimeout(function() {
        const flashes = document.querySelectorAll('.mmg-flash');
        flashes.forEach(function(flash) {
            flash.style.transition = 'opacity 0.3s, transform 0.3s';
            flash.style.opacity = '0';
            flash.style.transform = 'translateX(100%)';
            setTimeout(function() {
                if (flash.parentElement) {
                    flash.parentElement.removeChild(flash);
                }
            }, 300);
        });
    }, 4000);

})();
